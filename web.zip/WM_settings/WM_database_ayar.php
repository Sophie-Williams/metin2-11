<?php

// PANELİN KURULU OLDUĞU YERİN BİLGİLERİ

#ip adresi 
@define('ahost', '127.0.0.7');

#kullanıcı adı
@define('auser', 'root');

#mysql şifresi
@define('apass', '');

#veritabanı
@define('avt', 'wmcp');

?>