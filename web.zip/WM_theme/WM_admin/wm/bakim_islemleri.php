
<div id="content" class="content">

<h1 class="page-header"><small> Bakım işlemleri</small></h1>
                    
                    
<div class="row">
					
<div class="col-md-12">
						
<div class="panel panel-default">
<div class="panel-body">

<a onclick="WM_sil('bakim_islemleri&tur=1')" href="javascript:;" class="btn btn-danger"><i class="fa fa-trash"></i> Admin Loglarını Temizle </a>								
<a onclick="WM_sil('bakim_islemleri&tur=2')" href="javascript:;" class="btn btn-danger"><i class="fa fa-trash"></i> Ban Geçmişini Temizle </a>								
<a onclick="WM_sil('bakim_islemleri&tur=3')" href="javascript:;" class="btn btn-danger"><i class="fa fa-trash"></i> Silinmiş Karakter Geçmişini Temizle </a>								
<a onclick="WM_sil('bakim_islemleri&tur=4')" href="javascript:;" class="btn btn-danger"><i class="fa fa-trash"></i> Lonca Konuşmalarını Temizle </a>								
<a onclick="WM_sil('bakim_islemleri&tur=5')" href="javascript:;" class="btn btn-danger"><i class="fa fa-trash"></i> Log Veritabanını Boşalt </a>								
									
</div>
</div>
						
</div>                        
</div>
                    
                    
                    
</div>

