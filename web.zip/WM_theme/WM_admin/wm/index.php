<div id="content" class="content">

<ol class="breadcrumb pull-right">
<li class="active">Ana Sayfa</li>
</ol>
<h1 class="page-header">Ana Sayfa <small> serverınızın genel bilgileri</small></h1>

<div class="row">

			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-blue"><i class="ion-ios-person"></i></div>
			            <div class="stats-title">Toplam Kayıtlı Üye</div>
			            <div class="stats-number"><?=kullanici("tum");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc"> <a href="index.php?sayfa=kullanicilar" class="small-box-footer" target="_blank">Kullanıcıları Görün <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-red"><i class="ion-ios-close-empty"></i></div>
			            <div class="stats-title">Toplam Banlı Üye</div>
			            <div class="stats-number"><?=kullanici("ban");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc"> <a href="index.php?sayfa=banliuyeler" class="small-box-footer" target="_blank">Banlı Üyeleri Görün <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>

				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-purple"><i class="ion-ios-clock-outline"></i></div>
			            <div class="stats-title">Banı Kalkacak Üyeler</div>
			            <div class="stats-number"><?=kullanici("bangelmis");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=bankalkicak" class="small-box-footer" target="_blank">Banı Kalkıcak Üyeler <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-orange"><i class="ion-ios-people-outline"></i></div>
			            <div class="stats-title">Toplam Lonca</div>
			            <div class="stats-number"><?=kullanici("lonca");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=lonca" class="small-box-footer" target="_blank">Loncaları Görün <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				

</div>

<?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("r", $yetkiler))){ ?>


<div class="row">

			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-red"><i class="ion-ios-lightbulb"></i></div>
			            <div class="stats-title">Tüm Destek Talebi</div>
			            <div class="stats-number"><?=destek("tum");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=Teknik_destek" class="small-box-footer" target="_blank">Destek Talepleri <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-purple"><i class="ion-ios-loop-strong"></i></div>
			            <div class="stats-title">Cevap Bekleyen Talepler</div>
			            <div class="stats-number"><?=destek("bekleyen");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=Teknik_destek&tur=cevap_bekleyen" class="small-box-footer" target="_blank">Cevap Bekleyenler <i class="fa fa-arrow-circle-right"></i></a> </div>
			        </div>
			    </div>

				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-orange"><i class="ion-ios-list-outline"></i></div>
			            <div class="stats-title">Destek Departmanları</div>
			            <div class="stats-number"><?=destek("departman");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=destek_kategori" class="small-box-footer" target="_blank">Destek Departmanları <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-blue"><i class="ion-ios-checkmark-outline"></i></div>
			            <div class="stats-title">Ödeme Onaylı Talepler</div>
			            <div class="stats-number"><?=destek("odemeonayli");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">   <a href="index.php?sayfa=Teknik_destek&tur=odeme_onayli" class="small-box-footer" target="_blank">Onaylanmış Talepler <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				

</div>


<?php } ?>


<?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("s", $yetkiler))){ ?>


<div class="row">

			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-black"><i class="ion-ios-pricetags-outline"></i></div>
			            <div class="stats-title">Market İtemleri</div>
			            <div class="stats-number"><?=market("itemler");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">   <a href="index.php?sayfa=market_item" class="small-box-footer" target="_blank">Market İtemleri Gör <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-green"><i class="ion-ios-eye-outline"></i></div>
			            <div class="stats-title">Market Alınanlar</div>
			            <div class="stats-number"><?=market("alinan");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">   <a href="index.php?sayfa=market_log" class="small-box-footer" target="_blank">Marketten Alınanları Gör <i class="fa fa-arrow-circle-right"></i></a> </div>
			        </div>
			    </div>

				
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-red"><i class="ion-ios-list-outline"></i></div>
			            <div class="stats-title">Market Kategorileri</div>
			            <div class="stats-number"><?=market("kategori");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">  <a href="index.php?sayfa=market_kategori" class="small-box-footer" target="_blank">Market Kategorileri Gör <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				
			    <div class="col-md-3 col-sm-6">
			        <div class="widget widget-stats bg-white text-inverse">
			            <div class="stats-icon stats-icon-lg stats-icon-square bg-purple"><i class="ion-ios-flame"></i></div>
			            <div class="stats-title">Market Efsunları</div>
			            <div class="stats-number"><?=market("efsunlar");?></div>
			            <div class="stats-progress progress">
                            <div class="progress-bar" style="width: 70.1%;"></div>
                        </div>
                        <div class="stats-desc">    <a href="index.php?sayfa=market_efsun" class="small-box-footer" target="_blank">Market Efsunları Gör <i class="fa fa-arrow-circle-right"></i></a></div>
			        </div>
			    </div>
				

</div>


<?php } ?>


<div class="row">

                        <div class="col-md-4">
                            
<ul class="list-group">
  <li class="list-group-item">Toplam Savaçı Karakter : <?=karakter("savasci");?></li>
  <li class="list-group-item">Toplam Ninja Karakter : <?=karakter("ninja");?></li>
  <li class="list-group-item">Toplam Sura Karakter : <?=karakter("sura");?></li>
  <li class="list-group-item">Toplam Şaman Karakter : <?=karakter("saman");?></li>
</ul>
                            
                        </div>
						
						
						<div class="col-md-4">
                            
                            <!-- START PROJECTS BLOCK -->
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <div class="panel-title-box">
                                        En Son Kayıt Olan 5 Kullanıcı 
                                    </div>                                    
                                </div>
                                <div class="panel-body panel-body-table">
                                    
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th width="50%">Kullanıcı Adı</th>
                                                    <th width="30%">Tarih </th>
                                                   <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("a", $yetkiler))){ ?> <th width="20%"></th><?php } ?>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php 
									$kullanicilar = $odb->prepare("SELECT login,create_time FROM account ORDER BY create_time DESC LIMIT 5");
									$kullanicilar->execute();
									foreach($kullanicilar as $kullanici){
											?>
                                                <tr>
											<td><?=$kullanici["login"];?></td>
                                                    <td><?=WM_zaman_cevir($kullanici["create_time"]);?></td>
                                             <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("a", $yetkiler))){ ?>       <td>
<a class="btn btn-primary" href="index.php?sayfa=kullanicilar&login=<?=$kullanici["login"];?>" target="_blank"><i class="fa fa-eye"></i></a>
                                                    </td><?php } ?>
                                                </tr>
									<?php } ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END PROJECTS BLOCK -->
                            
                        </div>
						
						<div class="col-md-4">
                            
                            <!-- START PROJECTS BLOCK -->
                            <div class="panel panel-warning">
                                <div class="panel-heading">
                                    <div class="panel-title-box">
                                        En yüksek levelli 5 karakter
                                    </div>                                    
                                </div>
                                <div class="panel-body panel-body-table">
                                    
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th width="50%">Karakter Adı</th>
                                                    <th width="30%">Level</th>
                                                   <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("d", $yetkiler))){ ?> <th width="20%"></th><?php } ?>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php 
									$karakterler = $odb->prepare("SELECT name,level,job FROM player.player ORDER BY level DESC LIMIT 5");
									$karakterler->execute();
									foreach($karakterler as $karakter){
											?>
                                                <tr>
                          <td><img style="width:25px; height:20px;" src="<?=WMadmintema.'img/karakterler/'.$karakter["job"];?>.jpg"> <?=$karakter["name"];?></td>
                                                    <td><?=$karakter["level"];?></td>
                                   <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("d", $yetkiler))){ ?>                   <td>
<a class="btn btn-warning" href="index.php?sayfa=karakterler&name=<?=$karakter["name"];?>" target="_blank"><i class="fa fa-eye"></i></a>
                                                    </td><?php } ?>
                                                </tr>
									<?php } ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END PROJECTS BLOCK -->
                            
                        </div>
						
						

</div>

</div>