<div id="content" class="content">

<h1 class="page-header"><small> Kullanıcı Ep Yönetimi Paneli</small></h1>
                    
                    
                    <div class="row">
					
                        <div class="col-md-12">
						
							<div class="panel panel-default">
                                <div class="panel-heading ui-draggable-handle">
                                    <h3 class="panel-title"> Ep İşlemleri</h3>
                                </div>
                                <div class="panel-body">
									<div class="col-md-12">
									<label>Karakter adından kullanıcı adını bulmak için aşağıdaki kutucuğa karakterin adını giriniz.. </label></div>
									<?=$WMform->head("kullanicisorgula");?>
									<?=$WMform->veri("karakteradi", " Karakterin adını giriniz", "text", "6");?>
									<?=$WMform->buton(0, " Kullanıcı Sorgula", "primary", "search");?>
									<?=$WMform->footer();?>
									<br>
									<div class="col-md-12">
                                    <p><label>Ep Gönderilcek Kullanıcıyı Giriniz</label></p>
									<?=$WMform->head("epislem");?>
									<?=$WMform->veri("banlancak", "Ep gönderilcek kullanıcıyı giriniz.", "text");?>
                                    <p><label>Ep Yükseltmek İstiyor iseniz Örnek : 25 Azaltmak istiyor iseniz Örnek : -25</label></p>
									<?=$WMform->veri("epmiktar", "Ep gönderilcek kullanıcıyı giriniz.", "text", "", 'onkeyup="sayi_kontrol(this)"');?>
									<?=$WMform->buton(1, " Ep Gönder", "success btn-warning btn-block", "send");?>
									<?=$WMform->footer();?>
									</div>
									
                                </div>
                            </div>						
						
                            
                        </div>                        
                    </div>
					
					</div>
                    
                    
