<div id="content" class="content">

<h1 class="page-header"><small> Ep satın al sayfası</small></h1>
                    
                    
                    <div class="row">
					
                        <div class="col-md-12">
						
						
									<div class="panel panel-default">
									
									
												<div class="panel-heading ui-draggable-handle">
												Ep Satın Al Sayfasını Düzenliyorsunuz
												</div>
									<div class="panel-body">
					<?=$WMform->head("ep_satin_al");?>
				<textarea name="odeme" class="icerik"><?=$WMadmin->serverbilgi("odeme");?></textarea>
					<?=$WMform->buton(1, " Kayıt Et", "primary pull-right", "save");?>
					<?=$WMform->footer();?>
					
					
					
									</div>
									</div>
                            
                        </div>                        
                    </div>
                    
                                       
                </div>
