<?php
require_once WMadmintema.'footer.php';
?>