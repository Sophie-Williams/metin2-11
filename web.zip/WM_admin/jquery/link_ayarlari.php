<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$linkler       = array( );
$linkler[ 0 ]  = gvn::post('anasayfa');
$linkler[ 1 ]  = gvn::post('kaydol');
$linkler[ 2 ]  = gvn::post('siralama');
$linkler[ 3 ]  = gvn::post('indir');
$linkler[ 4 ]  = gvn::post('giris');
$linkler[ 5 ]  = gvn::post('hesap');
$linkler[ 6 ]  = gvn::post('cikis');
$linkler[ 7 ]  = gvn::post('destek');
$linkler[ 8 ]  = gvn::post('forum');
$linkler[ 9 ]  = gvn::post('bansorgula');
$linkler[ 10 ] = gvn::post('tanitim');
$linkler[ 11 ] = gvn::post('market');
$update        = $db->prepare( "UPDATE server SET linkler = ? WHERE id = ?" );
$guncelle      = $update->execute( array(
     json_encode( $linkler ),
    $_SESSION[ "server" ] 
) );
if ( $guncelle ) {
    $WMadmin->log_gonder( "Linkler değiştirildi" );
    $WMform->basari( "Linkler başarıyla güncellendi" );
} else {
    $WMform->hata();
}
?>