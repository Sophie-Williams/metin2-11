<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$pid               = gvn::get('pid');
$rank              = gvn::post('rank');
$type              = gvn::post('type');
$battle_type       = gvn::post('battle_type');
$level             = gvn::post('level');
$ai_flag           = gvn::post('ai_flag');
$attack_range      = gvn::post('attack_range');
$setRaceFlag       = gvn::post('setRaceFlag');
$setImmuneFlag     = gvn::post('setImmuneFlag');
$empire            = gvn::post('empire');
$folder            = gvn::post('folder');
$on_click          = gvn::post('on_click');
$aggressive_sight  = gvn::post('aggressive_sight');
$damage_min        = gvn::post('damage_min');
$damage_max        = gvn::post('damage_max');
$max_hp            = gvn::post('max_hp');
$aggressive_hp_pct = gvn::post('aggressive_hp_pct');
$regen_cycle       = gvn::post('regen_cycle');
$regen_percent     = gvn::post('regen_percent');
$gold_min          = gvn::post('gold_min');
$gold_max          = gvn::post('gold_max');
$exp               = gvn::post('exp');
$def               = gvn::post('def');
$attack_speed      = gvn::post('attack_speed');
$move_speed        = gvn::post('move_speed');
$st                = gvn::post('st');
$dx                = gvn::post('dx');
$ht                = gvn::post('ht');
$iq                = gvn::post('iq');
$drop_item         = gvn::post('drop_item');
$dam_multiply      = gvn::post('dam_multiply');
$update            = $odb->prepare( "UPDATE player.mob_proto SET rank = ?, type = ?, battle_type = ?, level = ?, ai_flag = ?, attack_range = ?, setRaceFlag = ?, setImmuneFlag = ?, empire = ?, folder = ?, on_click = ?, aggressive_sight = ?, damage_min = ?, damage_max = ?,
max_hp = ?, aggressive_hp_pct = ?, regen_cycle = ?, regen_percent = ?, gold_min = ?, gold_max = ?, exp = ?, def = ?, attack_speed = ?, move_speed = ?, st = ?, dx = ?, ht = ?, iq = ?, drop_item = ?, dam_multiply = ? WHERE vnum = ?
" );
$guncelle          = $update->execute( array(
     $rank,
    $type,
    $battle_type,
    $level,
    $ai_flag,
    $attack_range,
    $setRaceFlag,
    $setImmuneFlag,
    $empire,
    $folder,
    $on_click,
    $aggressive_sight,
    $damage_min,
    $damage_max,
    $max_hp,
    $aggressive_hp_pct,
    $regen_cycle,
    $regen_percent,
    $gold_min,
    $gold_max,
    $exp,
    $def,
    $attack_speed,
    $move_speed,
    $st,
    $dx,
    $ht,
    $iq,
    $drop_item,
    $dam_multiply,
    $pid 
) );
if ( $guncelle ) {
    $WMadmin->log_gonder( $pid . " Vnumlu Mob Düzenlendi" );
    $WMform->basari( "Mob başarıyla güncellendi" );
} else {
    $WMform->hata();
}
?>