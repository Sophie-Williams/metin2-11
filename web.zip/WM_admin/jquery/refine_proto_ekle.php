<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
@$id =  gvn::post('refine');
$ekle1   = gvn::post('ekle1');
$ekle2   = gvn::post('ekle2');
$ekle3   = gvn::post('ekle3');
$ekle4   = gvn::post('ekle4');
$ekle5   = gvn::post('ekle5');
$adet1   = gvn::post('adet1');
$adet2   = gvn::post('adet2');
$adet3   = gvn::post('adet3');
$adet4   = gvn::post('adet4');
$adet5   = gvn::post('adet5');
$cost    = gvn::post('cost');
$prob    = gvn::post('prob');
$kontrol = $odb->prepare( "SELECT id FROM player.refine_proto WHERE id = ?" ); 
$kontrol->execute( array(
     $id 
) );
if ( $kontrol->rowCount() ) {
    $WMform->hata( "Girdiğiniz refine id ' sine sahip bir veri zaten var" );
} else if ( !$id || $id == 0 ) {
    $WMform->hata( "Refine idsi boş bırakılamaz" );
} else {
    $insert = $odb->prepare( "INSERT INTO player.refine_proto SET id = ?, vnum0 = ?, vnum1 = ?, vnum2 = ?, vnum3 = ?, vnum4 = ?, count0 = ?, count1 = ?, count2 = ?, count3 = ?, count4 = ?, cost = ?, prob = ?" );
    $ekle   = $insert->execute( array(
         $id,
        $ekle1,
        $ekle2,
        $ekle3,
        $ekle4,
        $ekle5,
        $adet1,
        $adet2,
        $adet3,
        $adet4,
        $adet5,
        $cost,
        $prob 
    ) );
    if ( $ekle ) {
        $WMadmin->log_gonder( $id . " numaralı yükseltme verisi eklendi" );
        $WMform->basari( "Yükseltme verisi başarıyla eklendi" );
    } else {
        $WMform->hata();
    }
}
?>