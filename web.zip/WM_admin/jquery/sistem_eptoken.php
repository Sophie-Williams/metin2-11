<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('formid');
if ( $fid == 1 ) {
    $mail     = gvn::post('mail');
    $kullanan =  gvn::post('kullanan');
    if ( ( $mail != 1 && $mail != 2 ) || ( $kullanan != 1 && $kullanan != 2 ) ) {
        $WMform->hata( "Değerler 1 ve 2 nin dışında olamaz" );
    } else {
        $update   = $db->prepare( "UPDATE server SET eptoken = ? WHERE id = ? " );
        $guncelle = $update->execute( array(
             $mail . ',' . $kullanan,
            $_SESSION[ "server" ] 
        ) );
        if ( $guncelle ) {
            $WMadmin->log_gonder( "Ep Token Ayarlar Düzenlendi" );
            $WMform->basari( "Sistem ayarları başarıyla kaydedildi" );
        } else {
            $WMform->hata();
        }
    }
} else if ( $fid == 2 ) {
    @$id = gvn::get('id');
    $kontrol = $db->prepare( "SELECT id,token FROM eptoken WHERE id = ? && sid = ?" );
    $kontrol->execute( array(
         $id,
        $_SESSION[ "server" ] 
    ) );
    if ( $kontrol->rowCount() ) {
        $fetch = $kontrol->fetch( PDO::FETCH_ASSOC );
        $WMadmin->log_gonder( $fetch[ "token" ] . " Ep Tokeni Silindi" );
        $sil = $db->prepare( "DELETE FROM eptoken WHERE id = ? && sid = ?" );
        $sil->execute( array(
             $id,
            $_SESSION[ "server" ] 
        ) );
        if ( $sil ) {
            $WMform->basari( "Token Başarıyla Silindi" );
            $WMform->jquery_sil( 'tr#eptoken-' . $id . '' );
        } else {
            $WMform->hata();
        }
    } else {
        $WMform->hata( "Ep tokeni bulunamadı" );
    }
} else if ( $fid == 3 ) {
    $epmiktar = gvn::post('epmiktar');
    if ( !$epmiktar ) {
        $WMform->hata( "Ep miktarı boş bırakılamaz" );
    } else {
		$kactane = gvn::post('kac');
		for($i = 1; $i <= $kactane; $i++){
		$random1 = "";
		for($j = 0; $j <= 4; $j++){
        $random1       .= substr( str_shuffle( "ABCDEFGHJKLMNOPRSTUVYZWQ" ), 0, 5 )."-";
		}
		$random1 = substr($random1, 0, -1);
        $token_insert  = $db->prepare( "INSERT INTO eptoken SET sid = ?, token = ?, ep = ?, olusturan = ?, olusturma_tarih = ?" );
        $token_olustur = $token_insert->execute( array(
             $_SESSION[ "server" ],
            $random1,
            $epmiktar,
            ".!*23.",
            date( "Y-m-d H:i:s" ) 
        ) );
		
		}
		
            $WMadmin->log_gonder( $epmiktar . " Ep lik  ".$kactane." 25 tane token oluşturuldu" );
            $WMform->basari( "Token Başarıyla Oluşturuldu" );
            echo '<meta http-equiv="refresh" content="2;URL=#">';
		
    }
}
?>