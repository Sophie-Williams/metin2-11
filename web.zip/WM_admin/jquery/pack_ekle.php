<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$sira         = gvn::post('sira');
$pack         = gvn::post('pack');
$aciklama     = gvn::post('aciklama');
$boyut        = gvn::post('boyut');
$linkler      = gvn::post('linkler');
$sira_kontrol = $db->prepare( "SELECT sira FROM packlar WHERE sid = ? && sira = ?" );
$sira_kontrol->execute( array(
     $_SESSION[ "server" ],
    $sira 
) );
if ( $sira_kontrol->rowCount() ) {
    $WMform->hata( $sira . '. Sırada zaten bir pack var' );
} else if ( !$sira || !$pack || !$aciklama || !$boyut || !$linkler ) {
    $WMform->hata( 'Hiç Bir Alanı Boş Bırakamazsınız' );
} else {
    $WMadmin->log_gonder( $pack . " Adlı Pack Eklendi" );
    $insert = $db->prepare( "INSERT INTO packlar SET sid = ?, sira = ?, pack = ?, aciklama = ?, boyut = ?, linkler = ?" );
    $ekle   = $insert->execute( array(
         $_SESSION[ "server" ],
        $sira,
        $pack,
        $aciklama,
        $boyut,
        $linkler 
    ) );
    if ( $ekle ) {
        $WMform->basari( "Pack Başarıyla Eklendi" );
    } else {
        $WMform->hata();
    }
}
?>