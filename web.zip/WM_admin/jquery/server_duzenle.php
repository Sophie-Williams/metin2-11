<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$pid         = gvn::get('pid');
$host        = gvn::post('host');
$user        = gvn::post('user');
$pass        = gvn::post('pass');
$port        = gvn::post('port');
$isim        = gvn::post('isim');
$link        = gvn::post('link');
$title       = gvn::post('title');
$keywords    = gvn::post('keywords');
$description = gvn::post('description');
if ( !$host || !$user || !$port || !$isim || !$link || !$title ) {
    $WMform->hata( "* ile işaretlenen yerler boş bırakılamaz.." );
} else {
    $update   = $db->prepare( "UPDATE server SET host = ?, user = ?, pass = ?, sql_port = ?, isim = ?, link = ?, title = ?, keywords = ?, description = ? WHERE id = ?" );
    $guncelle = $update->execute( array(
         $host,
        $user,
        $pass,
        $port,
        $isim,
        $link,
        $title,
        $keywords,
        $description,
        $pid 
    ) );
    if ( $guncelle ) {
        $WMform->basari( "Server Ayarları Başarıyla Güncellendi" );
        $WMadmin->log_gonder( $isim . " Serverı Düzenlendi" );
        echo '<meta http-equiv="refresh" content="3;URL=#">';
    } else {
        $WMform->hata();
    }
}
?>