<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$fid     = gvn::get('fid');
$account = gvn::get('account');
$source  = gvn::get('source');
$sil     = $odb->prepare( "DELETE FROM ban_list WHERE account = ? && source = ?" );
$sil->execute( array(
     $account,
    $source 
) );
if ( $sil ) {
    $WMadmin->log_gonder( $source . " Adlı karakter ban listesinden kaldırıldı" );
    $WMform->jquery_sil( 'tr#ban_list-' . $fid . '' );
    $WMform->basari( " Karakter ban listesinden başarıyla kaldırıldı" );
} else {
    $WMform->hata();
}
?>