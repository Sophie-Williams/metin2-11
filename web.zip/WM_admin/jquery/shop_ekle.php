<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$vnum = gvn::post('vnum');
$npc  = gvn::post('npc');
$info = gvn::post('info');
if ( !$vnum || !$npc ) {
    $WMform->hata( "Shop veya Npc vnumunu boş bırakamazsınız. !" );
} else {
    $kontrol = $odb->prepare( "SELECT vnum FROM player.shop WHERE vnum = ?" );
    $kontrol->execute( array(
         $vnum 
    ) );
    if ( $kontrol->rowCount() ) {
        $WMform->uyari( "Böyle bir shop vnumuna sahip npc zaten var" );
    } else {
        $insert = $odb->prepare( "INSERT INTO player.shop SET vnum = ?, name = ?, npc_vnum = ?" );
        $ekle   = $insert->execute( array(
             $vnum,
            $info,
            $npc 
        ) );
        if ( $ekle ) {
            $WMadmin->log_gonder( $info . " adlı npc eklendi" );
            $WMform->basari( "NPC yi başarıyla eklediniz" );
        } else {
            $WMform->hata();
        }
    }
}
?>