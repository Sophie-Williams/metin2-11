<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('formid');
if ( $fid == 1 ) {
	$gmisim = gvn::post('gmisim');
    $icerik = gvn::post('icerik');
    @$imza = gvn::post('imza');
    if ( $imza ) {
        $imza_durum = 1;
    } else {
        $imza_durum = 2;
    }
    $update   = $db->prepare( "UPDATE users SET imza = ?, imza_durum = ?, gm = ? WHERE id = ?" );
    $guncelle = $update->execute( array(
         $icerik,
        $imza_durum,
		$gmisim,
        $_SESSION[ "adminid" ] 
    ) );
    if ( $guncelle ) {
        $WMform->basari( "Bilgileriniz başarıyla güncellendi" );
    } else {
        $WMform->hata();
    }
} else if ( $fid == 2 ) {
    $pass       = gvn::post('pass');
    $pass_retry = gvn::post('pass_retry');
    if ( !$pass ) {
        $WMform->hata( "Şifre boş bırakılamaz" );
    } else if ( $pass != $pass_retry ) {
        $WMform->hata( "Şifreler eşleşmiyor" );
    } else {
        $update   = $db->prepare( "UPDATE users SET password = ? WHERE id = ?" );
        $guncelle = $update->execute( array(
             md5( $pass ),
            $_SESSION[ "adminid" ] 
        ) );
        if ( $guncelle ) {
            $WMform->basari( "Şifreniz başarıyla değiştirildi" );
        } else {
            $WMform->hata();
        }
    }
}
?>