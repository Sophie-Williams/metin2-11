<?php
require_once '../WM_settings/WM_admin_ayar.php';

require_once WMadmintema.'giris.php';

require_once 'footer.php';
?>