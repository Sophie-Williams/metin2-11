<?php 

if($_GET["islem"] == "giris_yap")
{
require_once '../WM_settings/WM_database_ayar.php';

require_once '../WM_settings/WMdatabase.php';

require_once '../fonksiyon.php';

}
else
{

require_once 'fonksiyon.php';

}

$cek = gvn::get('islem');

$dizin	= "jquery/";

if(!$cek)
{
	
echo "Dosya yok ! ";

}
else
{
	
$bul = $dizin.$cek.".php";
if( file_exists($bul) )
{
	
require_once $bul;

}
else
{
	
printf('Aradığınız dosya yok');

} 

}

?>