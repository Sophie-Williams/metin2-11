function oyuncu_ara(){
var arancak = $("input[name=arancak]").val();

window.location.href = "oyuncu-siralamasi?isim="+arancak;

}

function online_ara(){
var arancak = $("input[name=arancak]").val();

window.location.href = "online-siralamasi?isim="+arancak;

}

function lonca_ara(){
var arancak = $("input[name=arancak]").val();

window.location.href = "lonca-siralamasi?isim="+arancak;

}

