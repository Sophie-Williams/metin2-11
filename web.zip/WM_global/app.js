$(document).ready(function (e) {
		
$(document).on('submit', 'form', (function(event) {
	
	
		var getUrlParameter = function getUrlParameter() {
		var sPageURL = decodeURIComponent(window.location.search.substring(1)),
			sURLVariables = sPageURL.split('&'),
			sParameterName,
			i;
			
		var getParameters = {};

		for (i = 0; i < sURLVariables.length; i++) {
			sParameterName = sURLVariables[i].split('=');
			
			getParameters[sParameterName[0]] = sParameterName[1];
		}
		
		return JSON.stringify(getParameters);
		
	};


var id = $(event.target).attr('id');

var enctype = $(event.target).attr('enctype');

var variable = $(event.target).attr('variable');

if(enctype == 'multipart/form-data') 
{
	
$.ajax({
url: "ajax.php?p="+id+"&variable="+variable+"&ln="+getUrlParameter(),
type: "POST",            
data:  new FormData(event.target), 
contentType: false,      
cache: false,             
processData:false,       
success: function(data)  
{
$("div#sonuc").html(data);
}
});

} 
else
{
	
$.ajax({
url: "ajax.php?p="+id+"&variable="+variable+"&ln="+getUrlParameter(),
type: "POST",            
data:  $(event.target).serialize(), 
success: function(cevap)  
{
$("div#sonuc").html(cevap);
}
});


}


}));

});

