<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<title><?=$vt->a("title");?></title>

<meta name="keywords" content="<?=$vt->a("keywords");?>">

<meta name="description" content="<?=$vt->a("description");?>">
