<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<table class="indirtbl">
  <tr>
	  <th>Token</th>
	  <th><?=($ayarlar[1] == 1) ? 'Kullanan' : 'Durum';?></th>
	  <th>İşlemler</th>
  </tr>
  <?php 
  foreach($eptokenler as $eptoken){
  ?>
  <form action="javascript:;" id="eptokenlerimkullan" variable="<?=$eptoken['id'];?>" method="post">
  <tr>
      <td ><?=$eptoken["token"];?></td>
	  <td><?php if($ayarlar[1] == 1){?> 
      <?=($eptoken["kullanan"] == "") ? 'Kullanılmamış' : '<font color="red">'.$eptoken["kullanan"].'</font>';?>
	  <?php }else { ?>
      <?=($eptoken["kullanan"] == "") ? 'Kullanılmamış' : '<font color="red">Kullanılmış</font>';?>
	  <?php } ?>
	  </td>
      <td >
		<?php if($eptoken["kullanan"] == ""){ ?><input name="kullan" type="submit" value="Kullan" /> <?php }else { 
		echo '<font color="red">Kullanıldı</font>';} ?> 
	  </td>
  </tr>
  </form>
  <?php } ?>
</table>
