<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div style="margin-bottom:20px"></div>

<a href="kullanici/karakterlerim?karakter=<?=$ll["player_id"];?>&guild_id=<?=$ll["id"];?>" class="prf_dznl"><img src="<?=$ayar->WMimg;?>edit.png">Lonca Profilini Düzenle</a>

<div style="margin-bottom:20px"></div>
