<?php
class kullanici_adi_degistir {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_adi_degistir/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_adi_degistir/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return @$_SESSION[ $vt->a( "isim" ) . "username" ] . ' -  Kullanıcı Adı Değiştir';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema, $WMinf;
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            $vt->yonlendir( $vt->url( 4 ) );
        } else if ( $vt->a( "kullanici_degis" ) == 3 ) {
            $vt->yonlendir( $vt->url( 5 ) );
        } else {
            if ( $vt->a( "breadcumb" ) == 1 ) {
                if ( file_exists( WM_tema . 'sayfalar/kullanici_adi_degistir/breadcumb.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_adi_degistir/breadcumb.php';
                } else {
                    require_once Sayfa_html . 'breadcumb.php';
                }
            }
            @$token_sayfa = gvn::get('token');
            @$user_sayfa = gvn::get('user');
            if ( !$token_sayfa || !$user_sayfa ) {
                if ( file_exists( WM_tema . 'sayfalar/kullanici_adi_degistir/kullanici_adi_degistir.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_adi_degistir/kullanici_adi_degistir.php';
                } else {
                    require_once Sayfa_html . 'kullanici_adi_degistir.php';
                }
            } else {
                if ( $vt->a( "kullanici_degis" ) == 2 ) {
                    $token_kontrol = $db->prepare( "SELECT token FROM token WHERE sid = ? && tur = ? && token = ? && login = ?" );
                    $token_kontrol->execute( array(
                         server,
                        4,
                        $token_sayfa,
                        $user_sayfa 
                    ) );
                    if ( $token_kontrol->rowCount() ) {
                        $parcala                 = explode( "_", $token_sayfa );
                        $degistirilcek_kullanici = $parcala[ 1 ];
                        $guncelle                = $odb->prepare( "UPDATE account SET login = ? WHERE login = ?" );
                        $guncelle->execute( array(
                             $degistirilcek_kullanici,
                            $user_sayfa 
                        ) );
                        if ( $guncelle->errorInfo()[2] == false ) {
                            $vt->tokenleri_sil( 4, $user_sayfa );
                            $WMinf->session_giris_sonlandir();
                            $vt->kullanici_log( "Kullanıcı adı değiştirildi" );
                            $tema->basari( "Kullanıcı Adınız Başarıyla " . $degistirilcek_kullanici . " olarak değiştirilmiştir. Çıkış yapılıyor." );
                            printf( '<meta http-equiv="refresh" content="3;URL=' . $vt->url( 4 ) . '">' );
                        } else {
                            $tema->hata( "Sistem hatası" );
                        }
                    }
                } else {
                    $vt->yonlendir( $vt->url( 0 ) );
                }
            }
        }
    }
}
?>