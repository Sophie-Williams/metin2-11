<?php
class kullanici_ep_tokenlerim {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_tokenlerim/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_ep_tokenlerim/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return $vt->a( "title" ) . ' - EP Tokenlerim';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema;
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            $vt->yonlendir( $vt->url( 4 ) );
        } else {
            @$eptokenler = $db->prepare( "SELECT * FROM eptoken WHERE sid = ? && olusturan = ? ORDER BY id DESC" );
            @$eptokenler->execute( array(
                 server,
                $_SESSION[ $vt->a( "isim" ) . "username" ] 
            ) );
            @$kontrol = $db->prepare( "SELECT eptoken FROM server LIMIT 1" );
            @$kontrol->execute( );
            if ( $kontrol->errorInfo()[2] != false ) {
                $vt->yonlendir( $vt->url( 0 ) );
            } else if ( $eptokenler->errorInfo()[2] == false ) {
                $ayarlar = explode( ',', $vt->a( "eptoken" ) );
                if ( $vt->a( "breadcumb" ) == 1 ) {
                    if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_tokenlerim/breadcumb.php' ) ) {
                        require_once WM_tema . 'sayfalar/kullanici_ep_tokenlerim/breadcumb.php';
                    } else {
                        require_once Sayfa_html . 'breadcumb.php';
                    }
                }
                if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_tokenlerim/tokenlerim.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_ep_tokenlerim/tokenlerim.php';
                } else {
                    require_once Sayfa_html . 'tokenlerim.php';
                }
            } else {
                $vt->yonlendir( $vt->url( 0 ) );
            }
        }
    }
}
?>