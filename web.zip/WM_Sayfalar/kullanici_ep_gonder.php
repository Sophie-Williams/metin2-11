<?php
class kullanici_ep_gonder {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_gonder/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_ep_gonder/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return @$_SESSION[ $vt->a( "isim" ) . "username" ] . ' -  EP Gönder';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema;
        @$select = $db->prepare( "SELECT id FROM eptransfer_log LIMIT 1" );
        @$select->execute( );
        @$select2 = $odb->prepare( "SELECT edurum, epass FROM account LIMIT 1" );
        @$select2->execute( );
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            $vt->yonlendir( $vt->url( 4 ) );
        } else if ( $select->errorInfo()[2] != false  || $select2->errorInfo()[2] != false  ) {
            $vt->yonlendir( $vt->url( 5 ) );
        } else {
            $eptransfer = explode( ',', $vt->a( "eptransfer" ) );
            if ( $eptransfer[ 0 ] == 1 && $vt->uye( "edurum" ) == 1 ) {
                if ( $vt->a( "breadcumb" ) == 1 ) {
                    if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_gonder/breadcumb.php' ) ) {
                        require_once WM_tema . 'sayfalar/kullanici_ep_gonder/breadcumb.php';
                    } else {
                        require_once Sayfa_html . 'breadcumb.php';
                    }
                }
                if ( $eptransfer[ 1 ] == 1 && $eptransfer[ 2 ] == 1 ) {
                    if ( strlen( $vt->uye( "epass" ) ) < 2 ) {
                        $random   = substr( str_shuffle( "abcdefghkl0123456789" ), 0, 7 );
                        $guncelle   = $odb->prepare( "UPDATE account SET epass = ? WHERE id = ? && login = ?" );
                        $guncelle->execute( array(
                             $random,
                            $_SESSION[ $vt->a( "isim" ) . "userid" ],
                            $_SESSION[ $vt->a( "isim" ) . "username" ] 
                        ) );
                        if ( $guncelle->errorInfo()[2] == false  ) {
                            $tema->uyari( "Ep transfer şifreniz kurallara uymadığından yeni şifre oluşturuldu. Şifreniz : <b>" . $random . "</b>" );
                            echo '<script>alert("Sayfayı yenilemeden önce uyarıyı oku ! "); </script>';
                        }
                    }
                }
                if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_gonder/ep_gonder.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_ep_gonder/ep_gonder.php';
                } else {
                    require_once Sayfa_html . 'ep_gonder.php';
                }
            } else {
                $vt->yonlendir( $vt->url( 5 ) );
            }
        }
    }
}
?>