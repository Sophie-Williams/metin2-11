<?php
class kullanici_basvuru
{
    public function head()
    {
        global $vt;
        if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/header.php'))
        {
            require_once WM_tema . 'sayfalar/kullanici_basvuru/header.php';
        }
        else
        {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust()
    {
        global $vt;
        return $vt->a("isim") . ' - Başvuru Formları';
    }
    public function orta()
    {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema, $WMinf;
        if (!isset($_SESSION[$vt->a("isim") . "token"]))
        {
            $vt->yonlendir($vt->url(4));
        }
        else
        {
            @$detay_basvuru = gvn::get('detay_basvuru');
            if (!$detay_basvuru)
            {
                if ($vt->a("breadcumb") == 1)
                {
                    if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/breadcumb.php'))
                    {
                        require_once WM_tema . 'sayfalar/kullanici_basvuru/breadcumb.php';
                    }
                    else
                    {
                        require_once Sayfa_html . 'breadcumb.php';
                    }
                }
                $sayfada = 25;
                $toplam_basvuru = $db->prepare("SELECT COUNT(id) FROM basvurular WHERE sid = ? ORDER BY id DESC");
                $toplam_basvuru->execute(array(
                    server
                ));
                $toplam_basvuru = $toplam_basvuru->fetchColumn();
                if ($toplam_basvuru != 0)
                {
                    $toplam_sayfa = ceil($toplam_basvuru / $sayfada);
                    $sayfa = isset($_GET['sayfa']) ? (int)$_GET['sayfa'] : 1;
                    if ($sayfa < 1)
                    {
                        $sayfa = 1;
                    }
                    if ($sayfa > $toplam_sayfa)
                    {
                        $sayfa = $toplam_sayfa;
                    }
                    $limit = ($sayfa - 1) * $sayfada;
                    $query = $db->prepare("SELECT konu,id FROM basvurular WHERE sid = ? ORDER BY id DESC LIMIT $limit, $sayfada");
                    $query->execute(array(
                        server
                    ));
                    if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/basvuru_formlari.php'))
                    {
                        require_once WM_tema . 'sayfalar/kullanici_basvuru/basvuru_formlari.php';
                    }
                    else
                    {
                        require_once Sayfa_html . 'basvuru_formlari.php';
                    }
                }
                else
                {
                    $tema->uyari("Başvuru Formu Bulunamadı. Kullanıcı yönetim paneline dönmek için <a href='" . $vt->url(5) . "'> tıklayınız. </a>");
                }
            }
            else
            {
                $kontrol = $db->prepare("SELECT * FROM basvurular WHERE sid = ? && id = ?");
                $kontrol->execute(array(
                    server,
                    $detay_basvuru
                ));
                if ($kontrol->rowCount())
                {
                    $fetch = $kontrol->fetch(PDO::FETCH_ASSOC);
                    $array_basvurular = json_decode($fetch["basvuranlar"], true);
                    $array_onaylanan = json_decode($fetch["onaylananlar"], true);
                    $array_red = json_decode($fetch["red_edilenler"], true);
                    $kullanici_adi = $_SESSION[$vt->a("isim") . "username"];
                    if ($fetch["bitis_tur"] == 1)
                    {
                        if (!$vt->zaman_bittimi($fetch["bitis"]))
                        {
                            $zaman_bittimi_return = true;
                        }
                        else
                        {
                            $zaman_bittimi_return = false;
                        }
                    }
                    else
                    {
                        $zaman_bittimi_return = true;
                    }
                    if (!isset($array_basvurular[$kullanici_adi]) && !isset($array_onaylanan[$kullanici_adi]) && !isset($array_red[$kullanici_adi]))
                    {
                        $durum = "Başvuru yapılmamış";
                    }
                    else if (isset($array_basvurular[$kullanici_adi]))
                    {
                        $durum = '<p class="basvuru_yapildi">Başvuru Yapıldı</p>';
                    }
                    else if (isset($array_onaylanan[$kullanici_adi]))
                    {
                        $durum = '<p class="basvuru_onaylandi">Başvurunuz Onaylandı</p>';
                    }
                    else if (isset($array_red[$kullanici_adi]))
                    {
                        $durum = '<p class="basvuru_red_edildi">Başvurunuz Red Edildi</p>';
                    }
                    else
                    {
                        $durum = "Belli değil";
                    }
                    if ($fetch["tur"] == 2)
                    {
                        if ($vt->a("breadcumb") == 1)
                        {
                            if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/breadcumb_2.php'))
                            {
                                require_once WM_tema . 'sayfalar/kullanici_basvuru/breadcumb_2.php';
                            }
                            else
                            {
                                require_once Sayfa_html . 'breadcumb_2.php';
                            }
                        }
                        if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/basvuru_durum.php'))
                        {
                            require_once WM_tema . 'sayfalar/kullanici_basvuru/basvuru_durum.php';
                        }
                        else
                        {
                            require_once Sayfa_html . 'basvuru_durum.php';
                        }
                        $tema->uyari("Başvurururken loncanın başkanı olduğunuzdan emin olun.");
                        if ($fetch["bitis"] != '')
                        {
                            $tema->uyari(($vt->zaman_bittimi($fetch["bitis"])) ? "Lonca Başvuru süresi bitmiştir. Daha başvuru yapamazsınız." : 'Lonca Başvuruları ' . $tema->zaman_cevir($fetch["bitis"], 2) . '  biticek ve işleme koyulcaktır');
                        }
                        echo '<center>' . html_entity_decode($fetch["icerik"]) . '</center> <div style="margin-bottom:15px;"></div>';
                        if ($zaman_bittimi_return == true)
                        {
                            if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/lonca_basvuru.php'))
                            {
                                require_once WM_tema . 'sayfalar/kullanici_basvuru/lonca_basvuru.php';
                            }
                            else
                            {
                                require_once Sayfa_html . 'lonca_basvuru.php';
                            }
                        }
                    }
                    else
                    {
                        if ($vt->a("breadcumb") == 1)
                        {
                            if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/breadcumb_2.php'))
                            {
                                require_once WM_tema . 'sayfalar/kullanici_basvuru/breadcumb_2.php';
                            }
                            else
                            {
                                require_once Sayfa_html . 'breadcumb_2.php';
                            }
                        }
                        if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/basvuru_durum.php'))
                        {
                            require_once WM_tema . 'sayfalar/kullanici_basvuru/basvuru_durum.php';
                        }
                        else
                        {
                            require_once Sayfa_html . 'basvuru_durum.php';
                        }
                        if ($fetch["bitis"] != '')
                        {
                            $tema->uyari(($vt->zaman_bittimi($fetch["bitis"])) ? "Başvuru süresi bitmiştir. Daha başvuru yapamazsınız." : 'Başvuru ' . $tema->zaman_cevir($fetch["bitis"], 2) . '  biticek ve işleme koyulcaktır');
                        }
                        echo '<center>' . html_entity_decode($fetch["icerik"]) . '</center> <div style="margin-bottom:15px;"></div>';
                        if ($zaman_bittimi_return == true)
                        {
                            if (file_exists(WM_tema . 'sayfalar/kullanici_basvuru/normal_basvuru.php'))
                            {
                                require_once WM_tema . 'sayfalar/kullanici_basvuru/normal_basvuru.php';
                            }
                            else
                            {
                                require_once Sayfa_html . 'normal_basvuru.php';
                            }
                        }
                    }
                }
                else
                {
                    $tema->uyari("Böyle bir başvuru formu yok başvuru formlarını görmek için <a href='kullanici/basvuru'>Tıklayınız</a>");
                }
            }
        }
    }
}
?>
