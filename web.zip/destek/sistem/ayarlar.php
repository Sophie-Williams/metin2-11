<?php

/*    DATABASE     */                  $db = new db_connect;

define('BASE_HREF', 'https://www.sanalpay.com.tr/guncel/sanalpay/');

define('LINK_HREF', 'https://127.0.0.7/pay/sanalpay/');

define( "TEMA",  'temalar/site/'. getir::ayar('tema') . '/' );

