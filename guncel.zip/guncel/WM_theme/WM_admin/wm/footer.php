	</div>
	
	<script src="<?=WMadmintema;?>assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/jquery-cookie/jquery.cookie.js"></script>
	<script src="<?=WMadmintema;?>assets/js/dashboard.min.js"></script>
	<script src="<?=WMadmintema;?>assets/js/apps.min.js"></script>
	<script src="<?=WMadmintema;?>assets/js/editor.js"></script>
	<script src="<?=WMadmintema;?>assets/WMajax.js"></script>
	<script src="<?=WMadmintema;?>assets/js/jquery.notify.min.js"></script>
	<script src="<?=WMadmintema;?>assets/js/jquery.modal.js"></script>
	
	<script src="<?=WMadmintema;?>assets/plugins/DataTables/media/js/jquery.dataTables.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/DataTables/media/js/dataTables.bootstrap.min.js"></script>
	<script src="<?=WMadmintema;?>assets/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js"></script>	
	
	<script>
	
		$(document).ready(function() {
			App.init();
			DashboardV2.init();
		});
		
		
	</script>
	
<script>
	$('textarea.icerik').jqte();
	
	// settings of status
	var jqteStatus = true;
	$(".status").click(function()
	{
		jqteStatus = jqteStatus ? false : true;
		$('textarea.icerik').jqte({"status" : jqteStatus})
	});
</script>
	
	<script>
        $('table#karaktersirala').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": false,
          "info": true,
          "autoWidth": false,
		  "iDisplayLength": 20
        });
        $('table#karaktersirala2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": false,
          "info": true,
          "autoWidth": false,
		  "iDisplayLength": 20
        });
</script>

	
</body>

</html>
