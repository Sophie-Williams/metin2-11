<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<head>
	<meta charset="utf-8" />
    <title>WMCP - <?=(!@gvn::get('sayfa')) ? "Ana Sayfa" : gvn::bread(gvn::get('sayfa')); $sayfa = gvn::get('sayfa');?></title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="<?=WMadmintema;?>assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/animate.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/style.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/stil.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL CSS STYLE ================== -->
    <link href="<?=WMadmintema;?>assets/plugins/jquery-jvectormap/jquery-jvectormap.css" rel="stylesheet" />
    <link href="<?=WMadmintema;?>assets/css/jquery.notify.css" rel="stylesheet" />
    <link href="<?=WMadmintema;?>assets/css/jquery.modal.css" rel="stylesheet" />
    <link href="<?=WMadmintema;?>assets/css/editor.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL CSS STYLE ================== -->
	
	<link href="<?=WMadmintema;?>assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/DataTables/extensions/Responsive/css/responsive.bootstrap.min.css" rel="stylesheet" />	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?=WMadmintema;?>assets/plugins/pace/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->
</head>
<body>

<div id="sonuc"></div>
<div id="ajax_post"></div>

<style type="text/css"></style>
	<!-- begin #page-loader -->
	<div id="page-loader" class="fade in"><span class="spinner"></span></div>
	<!-- end #page-loader -->
	
	<!-- begin #page-container -->
	<div id="page-container" class="fade page-sidebar-fixed page-header-fixed">
		<!-- begin #header -->
		<div id="header" class="header navbar navbar-default navbar-fixed-top">
			<!-- begin container-fluid -->
			<div class="container-fluid">
				<!-- begin mobile sidebar expand / collapse button -->
				<div class="navbar-header">
					<a href="index.html" class="navbar-brand"><span class="navbar-logo"></span> WMCP <b>admin</b></a>
					<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- end mobile sidebar expand / collapse button -->
				
				<ul class="nav navbar-nav">
					<a class="btn btn-primary" href="https://www.sanalpay.com.tr" target="_blank" style="margin-top:10px;">Sanalpay.com.tr ile 7/24 online ödeme alabilirsiniz.</a>
				</ul>
				
				<!-- begin header navigation right -->
				<ul class="nav navbar-nav navbar-right">
					
					<li class="dropdown">
						<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle icon">
							<i class="fa fa-support"></i>
							<span class="label"><?=destek("bekleyen");?></span>
						</a>
						<ul class="dropdown-menu media-list pull-right animated fadeInDown">
                            <li class="dropdown-header">Cevap Bekleyen Talepler (<?=destek("bekleyen");?>)</li>
							
                    <?php $cevapbekleyen = $db->query("SELECT * FROM destek 
                      WHERE (durum=0 OR durum=2) && sid = '".$_SESSION["server"]."' ORDER BY id DESC");  ?>
                    <?php foreach($cevapbekleyen as $cevapb){  ?>
					
                            <li class="media">
                                <a href="index.php?sayfa=Teknik_destek&tid=<?=$cevapb["id"];?>">
                                    <div class="media-left"><i class="ion-ios-email-outline media-object bg-blue"></i></div>
                                    <div class="media-body">
                                        <h6 class="media-heading">Açan : <?=$cevapb["acan"];?> <br> <?=$WMinf->kisalt($cevapb["konu"], 80);?></h6>
                                        <div class="text-muted f-s-11"><?=WM_zaman_cevir($cevapb["tarih"]);?></div>
                                    </div>
                                </a>
                            </li>
					
					
                    <?php }               $bildirimler = $db->query("SELECT * FROM bildirim WHERE sid = '".$_SESSION["server"]."' && alan = '".$_SESSION["adminisim"]."' && alici_tur = '2' && durum = '1'");  ?>
							
                            <li class="dropdown-footer text-center">
                                <a href="index.php?sayfa=Teknik_destek&tur=cevap_bekleyen">Cevap bekleyenleri gör</a>
                            </li>
						</ul>
					</li>
					
					<li class="dropdown">
						<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle icon">
							<i class="fa fa-bell"></i>
							<span class="label"><?=$bildirimler->rowCount();?></span>
						</a>
						<ul class="dropdown-menu media-list pull-right animated fadeInDown">
                            
							<li class="dropdown-header">Bildirimler (<?=$bildirimler->rowCount();?>)</li>
							
                    <?php foreach($bildirimler as $bildirim){ ?>
					
                            <li class="media">
                                <a href="javascript:;" onclick="WM_click('bildirim_goruntule&fid=1&olay_yeri=<?=$bildirim["olay_yeri"];?>&tur=<?=$bildirim["tur"];?>&bildirim_id=<?=$bildirim["id"];?>')">
                                    <div class="media-left"><i class="ion-ios-plus-empty media-object bg-blue"></i></div>
                                    <div class="media-body">
                                        <h6 class="media-heading"><?=$bildirim["bildirim"];?></h6>
                                    </div>
                                </a>
                            </li>
					
                    <?php } ?>
							
							
                            <li class="dropdown-footer text-center">
                                <a href="index.php?sayfa=bildirimler">Tüm Bildirimler</a>
                            </li>
						</ul>
					</li>
					
					<li>
						<a href="index.php?sayfa=hatalar"  class="icon">
							<i class="fa fa-warning"></i>
							<span class="label"><?=hatalar();?></span>
						</a>
					</li>
					
					<li class="dropdown navbar-user">
						<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
							<span class="hidden-xs"><?=$_SESSION["adminisim"];?></span> <b class="caret"></b>
						</a>
						<ul class="dropdown-menu animated fadeInLeft">
							<li class="arrow"></li>
							<li><a href="index.php?sayfa=kullanici_bilgilerini_duzenle">Profili Düzenle</a></li>
							<li><a href="cikis.php">Çıkış Yap</a></li>
						</ul>
					</li>
				</ul>
				<!-- end header navigation right -->
			</div>
			<!-- end container-fluid -->
		</div>
		<!-- end #header -->
		
		<!-- begin #sidebar -->
		<div id="sidebar" class="sidebar">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar user -->
				<ul class="nav">
					<li class="nav-profile">
						<div class="image">
						</div>
						<div class="info">
							<?=$_SESSION["adminisim"];?>
							<small>wmcp yönetim paneli</small>
						</div>
					</li>
				</ul>
				<!-- end sidebar user -->
				<!-- begin sidebar nav -->
				<ul class="nav">
				
					<li class="active">
						<a href="index.php?sayfa=sanalpay">
						    <i class="ion-ios-flame"></i>
						    <span>Sanalpay.com.tr</span>
					    </a>
					</li>
				
				
					<li class="nav-header">Server İşlemleri</li>
          <?php if($yonetim_tur == 2){ ?>
					<li class="<?=($sayfa == "server_ekle") ? "active" : ""; ?>">
						<a href="index.php?sayfa=server_ekle">
						    <i class="ion-ios-plus-empty"></i>
						    <span>Server Ekle</span>
					    </a>
					</li>
          <?php } ?>
		  
		  
          <li class="has-sub <?=(@$sayfa == "server_ayarlari" && gvn::get('id') != '') ? 'active' : '';   ?>">
						<a href="javascript:;">
							<span class="label label-theme m-l-5 pull-right"><?php $query = $db->query("SELECT * FROM server"); ?><?=$query->rowCount();?></span>
							<i class="ion-ios-pulse-strong"></i> 
							<span>Serverlar</span>
						</a>
						<ul class="sub-menu">
								  <?php
									foreach($query as $row){
										
										if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array($row["id"], $serverlar))){
									
										?>
								  <li class="has-sub  <?=($sayfa == "server_ayarlari" && gvn::get('id') == $row["id"]) ? 'active' : '';?>">
									<a href="javascript:;"> <span><?=$row["isim"];?></span> <span class="pull-right-container">
									<i class="fa fa-angle-left pull-right"></i>
									</span></a>
									<ul class="sub-menu">
									  <li><a href="javascript:;" onclick="WM_click('server_islemleri&formid=1&server_id=<?=$row["id"];?>')">Yönet </a></li>
									  <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("z", $yetkiler))){ ?>
									  <li class="<?=($sayfa == "server_ayarlari" && gvn::get('id') == $row["id"]) ? 'active' : '';?>"><a href="index.php?sayfa=server_ayarlari&id=<?=$row["id"];?>">Düzenle </a></li>
									  <?php } ?>
									</ul>
								  </li>
								  <?php
									}
									
									}
									?>
						</ul>
					</li>
					
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("y", $yetkiler))){ ?>
					
					<li class="<?=($sayfa == "server_ayar") ? "active" : ""; ?>">
						<a href="index.php?sayfa=server_ayar">
						    <i class="ion-ios-gear-outline"></i>
						    <span>Server Ayarları</span>
					    </a>
					</li>
					
		  <?php } ?>
					
					<li>
						<a href="<?=$WMadmin->serverbilgi("link");?>" target="_blank">
						    <i class="ion-leaf"></i>
						    <span>Server Sitesine Git</span>
					    </a>
					</li>
					
					<li class="nav-header">Server İşlemleri</li>
					
					<li class="<?=((empty($sayfa)) ? 'active' : '')?>">
						<a href="index.php">
						    <i class="ion-home bg-purple"></i>
						    <span>Ana Sayfa</span>
					    </a>
					</li>
					
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("a", $yetkiler)) || ($yonetim_tur == 1 && in_array("b", $yetkiler)) || ($yonetim_tur == 1 && in_array("c", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "ep_olan_hesaplar" OR $sayfa == "bugun_acilan_hesaplar" OR $sayfa == "kullanici_olustur" OR $sayfa == "ban_list" OR $sayfa == "kullanici_ara" OR $sayfa == "kullanicilar" OR $sayfa == "kullaniciban" OR $sayfa == "kullaniciban" OR $sayfa == "banliuyeler" OR  $sayfa =="bankalkicak" OR $sayfa == "epislem") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-person bg-gradient-blue"></i>
						    <span>Kullanıcı İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("a", $yetkiler))){ ?>
              <li class="<?=($sayfa == "kullanicilar") ? "active" : ""; ?>"><a href="index.php?sayfa=kullanicilar">Kullanıcıları Gör</a></li>
              <li class="<?=($sayfa == "bugun_acilan_hesaplar") ? "active" : ""; ?>"><a href="index.php?sayfa=bugun_acilan_hesaplar">Bugün Kayıt Olanlar</a></li>
              <li class="<?=($sayfa == "ep_olan_hesaplar") ? "active" : ""; ?>"><a href="index.php?sayfa=ep_olan_hesaplar">Epi Olan Hesaplar</a></li>
              <li class="<?=($sayfa == "kullanici_ara") ? "active" : ""; ?>"><a href="index.php?sayfa=kullanici_ara">Kullanıcı Ara</a></li>
              <li class="<?=($sayfa == "kullanici_olustur") ? "active" : ""; ?>"><a href="index.php?sayfa=kullanici_olustur">Kullanıcı Oluştur</a></li>
              <?php } ?>
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("b", $yetkiler))){ ?>
              <li class="<?=($sayfa == "kullaniciban") ? "active" : ""; ?>"><a href="index.php?sayfa=kullaniciban">Kullanıcı Banla</a></li>
              <li class="<?=($sayfa == "banliuyeler") ? "active" : ""; ?>"><a href="index.php?sayfa=banliuyeler">Banlı Kullanıcılar</a></li>
              <li class="<?=($sayfa == "bankalkicak") ? "active" : ""; ?>"><a href="index.php?sayfa=bankalkicak">Banı Kalkacak Üyeler</a></li>
              <li class="<?=($sayfa == "ban_list") ? "active" : ""; ?>"><a href="index.php?sayfa=ban_list">Ban Logları</a></li>
              <?php } ?>
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("c", $yetkiler))){ ?>
              <li class="<?=($sayfa == "epislem") ? "active" : ""; ?>"><a href="index.php?sayfa=epislem">Ep Yükle - Sil</a></li>
              <?php } ?>
						</ul>
					</li>
					
					
		  <?php } ?>
		  
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("d", $yetkiler)) || ($yonetim_tur == 1 && in_array("e", $yetkiler)) || ($yonetim_tur == 1 && in_array("f", $yetkiler)) || ($yonetim_tur == 1 && in_array("g", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "lonca_ara" OR $sayfa == "online_karakterler" OR $sayfa == "statu_editler" OR $sayfa == "karakterler" OR $sayfa == "lonca" OR $sayfa == "gm_islemleri" OR $sayfa == "karakter_ara" OR $sayfa == "onayli_karakter") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-person-stalker bg-gradient-orange"></i>
						    <span>Karakter İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("d", $yetkiler))){ ?>
              <li class="<?=($sayfa == "karakterler") ? "active" : ""; ?>"><a href="index.php?sayfa=karakterler">Karakterler</a></li>
              <li class="<?=($sayfa == "online_karakterler") ? "active" : ""; ?>"><a href="index.php?sayfa=online_karakterler">Online Karakterler</a></li>
              <li class="<?=($sayfa == "karakter_ara") ? "active" : ""; ?>"><a href="index.php?sayfa=karakter_ara">Karakter Ara</a></li>
              <li class="<?=($sayfa == "onayli_karakter") ? "active" : ""; ?>"><a href="index.php?sayfa=onayli_karakter">Onaylı Karakterler</a></li>
              <?php } ?>
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("e", $yetkiler))){ ?>
              <li class="<?=($sayfa == "lonca") ? "active" : ""; ?>"><a href="index.php?sayfa=lonca">Loncalar</a></li>
              <li class="<?=($sayfa == "lonca_ara") ? "active" : ""; ?>"><a href="index.php?sayfa=lonca_ara">Lonca Ara</a></li>
              <?php } ?>
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("f", $yetkiler))){ ?>
              <li class="<?=($sayfa == "gm_islemleri") ? "active" : ""; ?>"><a href="index.php?sayfa=gm_islemleri">GM İşlemleri</a></li>
              <?php } ?>
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("g", $yetkiler))){ ?>
              <li class="<?=($sayfa == "statu_editler") ? "active" : ""; ?>"><a href="index.php?sayfa=statu_editler">Statusu Editli Ara</a></li>
              <?php } ?>
						</ul>
					</li>
					
		  <?php } ?>
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("h", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "Npcshop" OR $sayfa == "Npc_Ekle" OR $sayfa == "Npc_Aktar") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-cart bg-gradient-red"></i>
						    <span>Npc İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "Npcshop") ? "active" : ""; ?>"><a href="index.php?sayfa=Npcshop">NPC ' LER</a></li>
              <li class="<?=($sayfa == "Npc_Ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=Npc_Ekle">NPC Ekle </a></li>
              <li class="<?=($sayfa == "Npc_Aktar") ? "active" : ""; ?>"><a href="index.php?sayfa=Npc_Aktar">NPC Aktar </a></li>
						</ul>
					</li>
					
		  <?php } ?>
		  
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("j", $yetkiler)) || ($yonetim_tur == 1 && in_array("g", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "item_islemleri" OR $sayfa == "İtem_ara" OR $sayfa == "Antiflag_hesapla" OR $sayfa == "İtem_olustur") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-color-wand bg-gradient-yellow"></i>
						    <span>İtem İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("j", $yetkiler))){ ?>
              <li class="<?=($sayfa == "İtem_ara") ? "active" : ""; ?>"><a href="index.php?sayfa=İtem_ara">İtem Ara </a></li>
              <li class="<?=($sayfa == "item_islemleri") ? "active" : ""; ?>"><a href="index.php?sayfa=item_islemleri">İtem İşlemleri </a></li>
              <li class="<?=($sayfa == "Antiflag_hesapla") ? "active" : ""; ?>"><a href="index.php?sayfa=Antiflag_hesapla">Anti Flag Hesapla </a></li>
              <li class="<?=($sayfa == "İtem_olustur") ? "active" : ""; ?>"><a href="index.php?sayfa=İtem_olustur">İtem Oluştur </a></li>
              <?php } ?>
						</ul>
					</li>
					
					
		  <?php } ?>
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("k", $yetkiler))){ ?>
		  
					
					<li class="has-sub <?=($sayfa == "Server_efsunlari" OR $sayfa == "Server_efsunlari_2") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-color-filter-outline bg-red"></i>
						    <span>Efsun İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "Server_efsunlari") ? "active" : ""; ?>"><a href="index.php?sayfa=Server_efsunlari">Server Efsunları Gör </a></li>
              <li class="<?=($sayfa == "Server_efsunlari_2") ? "active" : ""; ?>"><a href="index.php?sayfa=Server_efsunlari_2">Server 2.Efsunları Gör </a></li>
						</ul>
					</li>
					
					
		  <?php } ?>
		  
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("l", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "Refine_proto" OR $sayfa == "Refine_ayarlari") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-infinite bg-blue"></i>
						    <span>+ Basma İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "Refine_proto") ? "active" : ""; ?>"><a href="index.php?sayfa=Refine_proto">+ Basma Oranları </a></li>
              <li class="<?=($sayfa == "Refine_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=Refine_ayarlari">+ Basma Ayarları </a></li>
						</ul>
					</li>
					
		  <?php } ?>
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("m", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "Exp_ayarlari" OR $sayfa == "Mob_ayarlari") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-paw bg-purple"></i>
						    <span>Mob İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "Mob_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=Mob_ayarlari">Mob Ara / Düzenle </a></li>
              <li class="<?=($sayfa == "Exp_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=Exp_ayarlari">Exp Ayarları </a></li>
						</ul>
					</li>
					
		  <?php } ?>
					
					
					<li class="nav-header">Site İşlemleri</li>
					
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("n", $yetkiler))){ ?>
										
					<li class="has-sub <?=($sayfa == "site_bakim" OR $sayfa == "tema_ayarlari" OR $sayfa == 'destek_temalari' OR $sayfa == "domain_ana_sayfa" OR $sayfa == "site_temalari" OR $sayfa == "index_temalari" OR $sayfa == "market_temalari" OR $sayfa == "mail_temalari" ) ? "active" : ""; ?>"">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-photos"></i>
						    <span>Tema Ayarları </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "domain_ana_sayfa") ? "active" : ""; ?>"><a href="index.php?sayfa=domain_ana_sayfa">Domain Ana Sayfa Ayarları </a></li>
              <li class="<?=($sayfa == "tema_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=tema_ayarlari">Tema Ayarları </a></li>
              <li class="<?=($sayfa == "site_bakim") ? "active" : ""; ?>"><a href="index.php?sayfa=site_bakim">Site Bakım Ayarları </a></li>
              <li class="<?=($sayfa == "site_temalari") ? "active" : ""; ?>"><a href="index.php?sayfa=site_temalari">Site Temaları</a></li>
              <li class="<?=($sayfa == "index_temalari") ? "active" : ""; ?>"><a href="index.php?sayfa=index_temalari">İndex Şablonları</a></li>
              <li class="<?=($sayfa == "market_temalari") ? "active" : ""; ?>"><a href="index.php?sayfa=market_temalari">Market Temaları</a></li>
              <li class="<?=($sayfa == "destek_temalari") ? "active" : ""; ?>"><a href="index.php?sayfa=destek_temalari">Teknik Destek Temaları</a></li>
              <li class="<?=($sayfa == "mail_temalari" ) ? "active" : ""; ?>"><a href="index.php?sayfa=mail_temalari">Mail Şablonları </a></li>
						</ul>

			</li>
			
		  <?php } ?>
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("o", $yetkiler))){ ?>
					
					<li class="has-sub <?=($sayfa == "site_banlananlar" OR $sayfa == "istatistik_arttirma" OR $sayfa == "basvurular" OR $sayfa == "basvuru_ekle" OR $sayfa == "server_linkleri" OR $sayfa == "duyuru" OR $sayfa == "anasayfa_ayarlari" OR $sayfa == "site_ayarlari" OR $sayfa == "pack_ayarlari" OR $sayfa == "sistem_kur" OR $sayfa == "anket_ekle" OR $sayfa == "anket"  ) ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-cog"></i>
						    <span>Genel Site Ayarları </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "site_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=site_ayarlari">Genel Ayarlar </a></li>
              <li class="<?=($sayfa == "server_linkleri") ? "active" : ""; ?>"><a href="index.php?sayfa=server_linkleri">Link Ayarları </a></li>
              <li class="<?=($sayfa == "anasayfa_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=anasayfa_ayarlari">Krallar - Sosyal Ağ</a></li>
              <li class="<?=($sayfa == "site_banlananlar") ? "active" : ""; ?>"><a href="index.php?sayfa=site_banlananlar">Site İP Ban At</a></li>
              <li class="<?=($sayfa == "pack_ayarlari") ? "active" : ""; ?>"><a href="index.php?sayfa=pack_ayarlari">Pack Ayarları</a></li>
              <li class="<?=($sayfa == "istatistik_arttirma") ? "active" : ""; ?>"><a href="index.php?sayfa=istatistik_arttirma">İstatistik Arttırma</a></li>
              <li class="<?=($sayfa == "sistem_kur") ? "active" : ""; ?>"><a href="index.php?sayfa=sistem_kur">Sistem Kur / Ayarlar</a></li>
							  <li class="has-sub <?=($sayfa == "basvurular" OR $sayfa == "basvuru_ekle") ? "active" : ""; ?>">
								<a href="#">Başvuru İşlemleri             <span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
								</span>
								</a>
						<ul class="sub-menu">
                  <li class="<?=($sayfa == "basvuru_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=basvuru_ekle">Başvuru Formu Ekle </a></li>
                  <li class="<?=($sayfa == "basvurular") ? "active" : ""; ?>"><a href="index.php?sayfa=basvurular">Başvuru Görüntüle / Düzenle</a></li>
								</ul>
							  </li>
							  <li class="has-sub <?=($sayfa == "anket" OR $sayfa == "anket_ekle") ? "active" : ""; ?>">
								<a href="#">Anket İşlemleri             <span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
								</span>
								</a>
						<ul class="sub-menu">
                  <li class="<?=($sayfa == "anket_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=anket_ekle">Anket Ekle </a></li>
                  <li class="<?=($sayfa == "anket") ? "active" : ""; ?>"><a href="index.php?sayfa=anket">Anket Görüntüle / Düzenle</a></li>
								</ul>
							  </li>
							  <li class="has-sub <?=($sayfa == "duyuru") ? "active" : ""; ?>">
								<a href="#">Duyuru İşlemleri             <span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
								</span>
								</a>
						<ul class="sub-menu">
                  <li class="<?=($sayfa == "duyuru" && $_GET["islem"] == "ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=duyuru&islem=ekle">Duyuru Ekle </a></li>
                  <li class="<?=($sayfa == "duyuru" && !$_GET["islem"]) ? "active" : ""; ?>"><a href="index.php?sayfa=duyuru">Duyuru Görüntüle / Düzenle</a></li>
								</ul>
							  </li>
							</ul>
			
			</li>
			
		  <?php } ?>
			
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("p", $yetkiler))){ ?>
			
			
					<li class="has-sub <?=($sayfa == "ep_satin_al_sayfasi" OR $sayfa == "sayfa" OR $sayfa == "sayfa_ekle") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-list-outline"></i>
						    <span>Sayfa Ayarları </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "sayfa_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=sayfa_ekle"> Sayfa Ekle </a></li>
              <li class="<?=($sayfa == "sayfa") ? "active" : ""; ?>"><a href="index.php?sayfa=sayfa"> Sayfa Gör / Düzenle </a></li>
              <li class="<?=($sayfa == "ep_satin_al_sayfasi") ? "active" : ""; ?>"><a href="index.php?sayfa=ep_satin_al_sayfasi"> EP Satın Al Sayfası</a></li>
						</ul>

			</li>
			
		  <?php } ?>
		  
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("r", $yetkiler))){ ?>

			
					<li class="has-sub <?=($sayfa == "destek_kategori_ekle" OR $sayfa == "Teknik_destek" OR $sayfa == "destek_kategori" OR @$_GET["tur"] == "cevap_bekleyen" OR @$_GET["tur"] == "odeme_onayli" ) ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-lightbulb"></i>
						    <span>Destek İşlemleri </span> 
						</a>
						<ul class="sub-menu">
              <?php if($yonetim_tur == 2){ ?>
              <li class="<?=($sayfa == "destek_kategori_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=destek_kategori_ekle">Destek Kategori Ekle </a></li>
              <li class="<?=($sayfa == "destek_kategori") ? "active" : ""; ?>"><a href="index.php?sayfa=destek_kategori">Destek Kategorileri </a></li>
			  <?php } ?>
              <li class="<?=($sayfa == "Teknik_destek" && !@$_GET["tur"]) ? "active" : ""; ?>"><a href="index.php?sayfa=Teknik_destek">Tüm Talepler </a></li>
              <li class="<?=(@$_GET["tur"] == "cevap_bekleyen") ? "active" : ""; ?>"><a href="index.php?sayfa=Teknik_destek&tur=cevap_bekleyen">Cevap Bekleyen Talepler </a></li>
              <li class="<?=(@$_GET["tur"] == "odeme_onayli") ? "active" : ""; ?>"><a href="index.php?sayfa=Teknik_destek&tur=odeme_onayli">Ödeme Onaylı Bildirimler </a></li>
							</ul>
			</li>
			
			
		  <?php } ?>
			
			
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("s", $yetkiler))){ ?>
			
					<li class="has-sub <?=($sayfa == "market_duyurular" OR $sayfa == "market_duyuru_ekle" OR $sayfa == "ep_fiyatlari" OR $sayfa == "market_kategori" OR $sayfa == "market_item_ekle" OR $sayfa == "market_item" OR $sayfa == "market_efsun_ekle" OR $sayfa == "market_efsun"  OR $sayfa == "market_tas" OR $sayfa == "market_log") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-pricetag"></i>
						    <span>Market İşlemleri </span> 
						</a>
						
						<ul class="sub-menu">
              <li class="<?=($sayfa == "market_kategori") ? "active" : ""; ?>"><a href="index.php?sayfa=market_kategori">Market Kategori </a></li>
              <li class="<?=($sayfa == "market_item_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=market_item_ekle">Market İtem Ekle </a></li>
              <li class="<?=($sayfa == "market_item") ? "active" : ""; ?>"><a href="index.php?sayfa=market_item">Market İtem Düzenle </a></li>
              <li class="<?=($sayfa == "market_efsun_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=market_efsun_ekle">Market Efsun Ekle </a></li>
              <li class="<?=($sayfa == "market_efsun") ? "active" : ""; ?>"><a href="index.php?sayfa=market_efsun">Market Efsun Düzenle </a></li>
              <li class="<?=($sayfa == "market_tas") ? "active" : ""; ?>"><a href="index.php?sayfa=market_tas">Market Taş </a></li>
              <li class="<?=($sayfa == "market_log") ? "active" : ""; ?>"><a href="index.php?sayfa=market_log">Alınanlar </a></li>
              <li class="<?=($sayfa == "ep_fiyatlari") ? "active" : ""; ?>"><a href="index.php?sayfa=ep_fiyatlari">Ep Fiyatları </a></li>
					<li class="has-sub <?=($sayfa == "market_duyurular" OR $sayfa == "market_duyuru_ekle") ? "active" : ""; ?>">
                <a href="#">Market Duyuru İşlemleri <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                </span></a>
						<ul class="sub-menu">
                  <li class="<?=($sayfa == "market_duyuru_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=market_duyuru_ekle">Duyuru Ekle </a></li>
                  <li class="<?=($sayfa == "market_duyurular") ? "active" : ""; ?>"><a href="index.php?sayfa=market_duyurular">Duyuru Görüntüle / Düzenle</a></li>
                </ul>
              </li>
            </ul>
			
			</li>
			
		  <?php } ?>
			
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("t", $yetkiler))){ ?>
					<li class="<?=($sayfa == "mail_ayarlari") ? "active" : ""; ?>">
						 <a href="index.php?sayfa=mail_ayarlari">
						    <i class="ion-ios-email-outline"></i>
						    <span>Mail Ayarları</span> 
						</a>
					</li>
					
		  <?php } ?>
		  
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("u", $yetkiler))){ ?>
		  
					
					<li class="has-sub <?=($sayfa == "giris_log" OR $sayfa == "hile_loglari" OR $sayfa == "gm_loglari" OR $sayfa == "ch_loglari" OR  $sayfa == "bagirma_loglari" OR $sayfa == "log" OR $sayfa == "kullanici_log") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-eye"></i>
						    <span>Loglar </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "log") ? "active" : ""; ?>"><a href="index.php?sayfa=log"> Panel Admin Logları </a></li>
              <li class="<?=($sayfa == "kullanici_log") ? "active" : ""; ?>"><a href="index.php?sayfa=kullanici_log"> Kullanıcı Logları </a></li>
              <li class="<?=($sayfa == "giris_log") ? "active" : ""; ?>"><a href="index.php?sayfa=giris_log"> Giriş Logları </a></li>
              <li class="<?=($sayfa == "hile_loglari") ? "active" : ""; ?>"><a href="index.php?sayfa=hile_loglari"> Hile Logları </a></li>
              <li class="<?=($sayfa == "gm_loglari") ? "active" : ""; ?>"><a href="index.php?sayfa=gm_loglari"> GM Logları </a></li>
              <li class="<?=($sayfa == "ch_loglari") ? "active" : ""; ?>"><a href="index.php?sayfa=ch_loglari"> CH Logları </a></li>
              <li class="<?=($sayfa == "bagirma_loglari") ? "active" : ""; ?>"><a href="index.php?sayfa=bagirma_loglari"> Bağırma Logları </a></li>
            </ul>

			</li>
			
			
          <?php } ?>
		  
			
          <?php  if(($yonetim_tur == 2) || ($yonetim_tur == 1 && in_array("u", $yetkiler))){ ?>
					<li class="<?=($sayfa == "bakim_islemleri") ? "active" : ""; ?>">
						 <a href="index.php?sayfa=bakim_islemleri">
						    <i class="ion-ios-trash-outline"></i>
						    <span>Bakım Ayarları</span> 
						</a>
					</li>
					
		  <?php } ?>
		  
          <?php  if($yonetim_tur == 2){ ?>
					
					<li class="has-sub <?=($sayfa == "alt_kullanici_ekle" OR $sayfa == "alt_kullanicilar") ? "active" : ""; ?>">
						<a href="javascript:;">
						    <b class="caret pull-right"></b>
						    <i class="ion-ios-body-outline"></i>
						    <span>Alt Kullanıcı Ayarları </span> 
						</a>
						<ul class="sub-menu">
              <li class="<?=($sayfa == "alt_kullanici_ekle") ? "active" : ""; ?>"><a href="index.php?sayfa=alt_kullanici_ekle">Alt Kullanıcı Ekle</a></li>
              <li class="<?=($sayfa == "alt_kullanicilar") ? "active" : ""; ?>"><a href="index.php?sayfa=alt_kullanicilar">Alt Kullanıcılar </a></li>
						</ul>

			</li>
			
		  <?php } ?>
					
					
					
					
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		
		<!-- begin #content -->
