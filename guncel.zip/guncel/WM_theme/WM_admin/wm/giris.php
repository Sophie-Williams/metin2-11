<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<title>WMCP - Giriş Yap</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<link href="<?=WMadmintema;?>assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/animate.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/style.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="<?=WMadmintema;?>assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<script src="<?=WMadmintema;?>assets/plugins/pace/pace.min.js"></script>
</head>
<body class="pace-top">
	<!-- begin #page-loader -->
	<div id="page-loader" class="fade in"><span class="spinner"></span></div>
	<!-- end #page-loader -->
	
	<!-- begin #page-container -->
	<div id="page-container" class="fade">
	    <!-- begin login -->
        <div class="login bg-black animated fadeInDown">
            <!-- begin brand -->
            <div class="login-header">
                <div class="brand">
                    <span class="logo"><i class="ion-ios-cloud"></i></span> WMCP Admin
                    <small>Metin2 Yönetim Paneli</small>
                </div>
                <div class="icon">
                    <i class="ion-ios-locked"></i>
                </div>
            </div>
            <!-- end brand -->
            <div class="login-content">
			<form action="javascript:void(0);" id="giris_yap">
			
	<div id="girisyapildimi" style="margin-top:-17px;"></div>
			
                    <div class="form-group m-b-20">
                        <input type="text" class="form-control input-lg inverse-mode no-border" placeholder="Kullanıcı adınızı giriniz" name="username" required />
                    </div>
                    <div class="form-group m-b-20">
                        <input type="password" class="form-control input-lg inverse-mode no-border" placeholder="Şifrenizi Giriniz" name="password" required />
                    </div>
                    <div class="login-buttons">
                        <button onclick="giris_yap()" type="submit" class="btn btn-primary btn-block btn-lg">Giriş Yap</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- end login -->
        
	</div>
	
	<div id="ajax_post"></div>

