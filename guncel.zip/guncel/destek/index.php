<?php

# Sistemi Başlat

require_once(dirname(__FILE__) . '/sistem/baslat.php');

# Tema Ayarları

require_once(dirname(__FILE__) . '/sistem/get.php');

