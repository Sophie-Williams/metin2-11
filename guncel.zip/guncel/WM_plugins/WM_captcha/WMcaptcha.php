<?php
session_start();
$captcha_code = substr(str_shuffle("0123456789"), 0, 4);
$_SESSION["captcha_code"] = $captcha_code;
$target_layer = imagecreatetruecolor(60,30);
$captcha_background = imagecolorallocate($target_layer, 111, 33, 33);
imagefill($target_layer,0,0,$captcha_background);
$captcha_text_color = imagecolorallocate($target_layer, 255, 255, 255);
imagestring($target_layer, 55, 10, 5, $captcha_code, $captcha_text_color);
header("Content-type: image/jpeg");
imagejpeg($target_layer);
?>