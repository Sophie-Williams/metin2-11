<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$pid       = gvn::get('pid');
$type      = gvn::post('type');
$subtype   = gvn::post('subtype');
$size      = gvn::post('size');
$yukselcek = gvn::post('yukselcek');
$refineid  = gvn::post('refineid');
$antiflag  = gvn::post('antiflag');
$flag      = gvn::post('flag');
$wearflag  = gvn::post('wearflag');
$gold      = gvn::post('gold');
$buy       = gvn::post('buy');
$lvsinir   = gvn::post('lvsinir');
$lv        = gvn::post('lv');
$efsun1    = gvn::post('efsun1');
$oran1     = gvn::post('oran1');
$efsun2    = gvn::post('efsun2');
$oran2     = gvn::post('oran2');
$efsun3    = gvn::post('efsun3');
$oran3     = gvn::post('oran3');
$taslar    = gvn::post('taslar');
$itemvarmi = $odb->prepare( "SELECT vnum FROM player.item_proto WHERE vnum = ?" );
$itemvarmi->execute( array(
     $pid 
) );
if ( $itemvarmi->rowCount() ) {
    $update   = $odb->prepare( "UPDATE player.item_proto SET type = :type, subtype = :subtype, size = :size, refined_vnum = :yukselcek, refine_set = :refineid, antiflag = :antiflag, flag = :flag,
	wearflag = :wearflag, gold = :gold, shop_buy_price = :buy, limittype0 = :lvsinir, limitvalue0 = :lv, applytype0 = :efsun1, applytype1 = :efsun2, applytype2 = :efsun3,
	applyvalue0 = :oran1, applyvalue1 = :oran2, applyvalue2 = :oran3, socket_pct = :taslar WHERE vnum = :pid
	" );
    $guncelle = $update->execute( array(
         "type" => $type,
        "subtype" => $subtype,
        "size" => $size,
        "yukselcek" => $yukselcek,
        "refineid" => $refineid,
        "antiflag" => $antiflag,
        "flag" => $flag,
        "wearflag" => $wearflag,
        "gold" => $gold,
        "buy" => $buy,
        "lvsinir" => $lvsinir,
        "lv" => $lv,
        "efsun1" => $efsun1,
        "efsun2" => $efsun2,
        "efsun3" => $efsun3,
        "oran1" => $oran1,
        "oran2" => $oran2,
        "oran3" => $oran3,
        "taslar" => $taslar,
        "pid" => $pid 
    ) );
    if ( $guncelle ) {
        $WMadmin->log_gonder( $WMadmin->item_bul( $pid ) . " Adlı item düzenlendi" );
        $WMform->basari( "İtem başarıyla güncellendi" );
    } else {
        $WMform->hata();
    }
} else {
    $WMform->hata( " Düzenlemeye çalıştığınız item artık yok" );
}
?>