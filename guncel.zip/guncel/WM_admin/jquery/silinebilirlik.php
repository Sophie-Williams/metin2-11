<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}

session_start();

$get = gvn::get('get');

if($get == 'durum'){
	if(isset($_SESSION['veri_silme'])){
		echo 1;
	}
	else{
		echo 2;
	}
}
else if($get == 'sifregirildi'){
	$sifre = gvn::get('sifre');
	
	if($sifre == veriSilmeSifresi){
		$WMform->basari("Veri silme şifrenizi doğru girdiniz. Artık veri silebilirsiniz");
		$_SESSION['veri_silme'] = true;
	}
	else{
		$WMform->hata("Veri silme şifrenizi yanlış girdiniz");
	}
	
}

?>