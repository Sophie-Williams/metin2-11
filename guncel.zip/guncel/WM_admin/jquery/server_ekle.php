<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();


$pid         = gvn::get('pid');
$host        = gvn::post('host');
$user        = gvn::post('user');
$pass        = gvn::post('pass');
$port        = gvn::post('port');
$isim        = gvn::post('isim');
$link        = gvn::post('link');
$klasor      = gvn::post('klasor');
$title       = gvn::post('title');
$keywords    = gvn::post('keywords');
$description = gvn::post('description');
$kontrol     = $db->prepare( "SELECT id FROM server WHERE klasor = ?" );
$kontrol->execute( array(
     $klasor 
) );
$kontrol2 = $db->prepare( "SELECT id FROM server WHERE isim = ?" );
$kontrol2->execute( array(
     $isim 
) );
if ( !$host || !$user || !$port || !$isim || !$link || !$title || !$klasor ) {
    $WMform->hata( "* ile işaretlenen yerler boş bırakılamaz.." );
} else if ( file_exists( "../$klasor" ) ) {
    $WMform->hata( "Böyle bir klasör zaten var" );
} else if ( $kontrol->rowCount() ) {
    $WMform->hata( $klasor . " klasörüne sahip bir server var" );
} else if ( $kontrol2->rowCount() ) {
    $WMform->hata( $isim . " isimli bir server zaten var" );
} else {
    $auto = $db->prepare( "SHOW TABLE STATUS LIKE ?" );
    $auto->execute( array(
         'server' 
    ) );
    $increment = $auto->fetch( PDO::FETCH_ASSOC );
    @mkdir( "../$klasor", 0777 );
    $yeni_dosya = "../$klasor/index.php";
    touch( $yeni_dosya );
    @file_put_contents( $yeni_dosya, "<?php " . $WMclass->server_yazdir( $increment[ "Auto_increment" ] ), FILE_APPEND );
    @copy( "../htaccess.txt", "../$klasor/.htaccess" );
    $insert = $db->prepare( "INSERT INTO server SET host = ?, user = ?, klasor = ?, pass = ?, sql_port = ?, isim = ?, link = ?, title = ?, keywords = ?, description = ?" );
    $ekle   = $insert->execute( array(
         $host,
        $user,
        $klasor,
        $pass,
        $port,
        $isim,
        $link,
        $title,
        $keywords,
        $description 
    ) );
    if ( $ekle ) {
        $WMform->basari( "Server Başarıyla Eklendi" );
    } else {
        $WMform->hata();
    }
}
?>