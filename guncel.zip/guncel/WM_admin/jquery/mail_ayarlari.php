<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('formid');
if ( $fid == 1 ) {
    $mailhost   = gvn::post('mailhost');
    $mailuser   = gvn::post('mailuser');
    $mailpass   = gvn::post('mailpass');
    $mailport   = gvn::post('mailport');
    $mailisim   = gvn::post('mailisim');
    $mail       = gvn::post('mail');
    $security   = gvn::post('security');
    $admin_mail = gvn::post('admin_mail');
    $update     = $db->prepare( "UPDATE ayarlar SET mail_host = ?, mail_user = ?, mail_pass = ?, mail_port = ?, mail_isim = ?, mail_profil = ?, mail_secure = ?, admin_mail = ?" );
    $guncelle   = $update->execute( array(
         $mailhost,
        $mailuser,
        $mailpass,
        $mailport,
        $mailisim,
        $mail,
        $security,
        $admin_mail 
    ) );
    if ( $guncelle ) {
        $WMadmin->log_gonder( "Mail ayarları güncellendi" );
        $WMform->basari( "Mail ayarları başarıyla değiştirildi" );
    } else {
        $WMform->hata();
    }
}
?>