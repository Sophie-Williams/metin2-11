<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriÅŸ izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('fid');
if ( $fid == 1 ) {
    $olay_yeri   = gvn::get('olay_yeri');
    $bildirim_id = gvn::get('bildirim_id');
    $tur         = gvn::get('tur');
    if ( $tur == 2 ) {
        $WMadmin->yonlendir( "index.php?sayfa=Teknik_destek&tid=" . $olay_yeri );
        $WMadmin->bildirim_okundu( $bildirim_id );
    } else if ( $tur == 3 ) {
        $WMadmin->yonlendir( "index.php?sayfa=basvurular&id=" . $olay_yeri );
        $WMadmin->bildirim_okundu( $bildirim_id );
    }
} else if ( $fid == 2 ) {
    $pid    = gvn::get('pid');
    $delete = $db->prepare( "DELETE FROM bildirim WHERE id = ? && sid = ?" );
    $sil    = $delete->execute( array(
         $pid,
        $_SESSION[ "server" ] 
    ) );
    if ( $sil ) {
        $WMform->jquery_sil( 'tr#bildirim-' . $pid . '' );
        $WMform->basari( "Bildirim başarıyla silindi" );
    } else {
        $WMform->hata();
    }
}
?>