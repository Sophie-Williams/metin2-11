<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$pid      = gvn::get('pid');
$gid      = gvn::get('gid');
$grade    = gvn::get('grade');
$guncelle = $odb->prepare( "UPDATE player.guild_member SET grade = ? WHERE pid = ? && guild_id = ?" );
$update   = $guncelle->execute( array(
     $grade,
    $pid,
    $gid 
) );
if ( $update ) {
    $WMadmin->log_gonder( $WMadmin->karakter( $pid, "name", 2 ) . " adlı karakterin lonca yetkisi düzenlendi" );
    $WMform->basari( "Üyenin yetkisi başarıyla değiştirildi" );
    echo '<meta http-equiv="refresh" content="2;URL=#">';
} else {
    $WMform->hata();
}
?>