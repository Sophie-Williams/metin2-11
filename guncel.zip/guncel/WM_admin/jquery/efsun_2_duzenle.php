<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
$formid   = gvn::get('formid');
$apply    = gvn::post("apply-$formid");
$gelme    = gvn::post("gelme-$formid");
$lv1      = gvn::post("lv1-$formid");
$lv2      = gvn::post("lv2-$formid");
$lv3      = gvn::post("lv3-$formid");
$lv4      = gvn::post("lv4-$formid");
$lv5      = gvn::post("lv5-$formid");
$silah    = gvn::post("silah-$formid");
$zirh     = gvn::post("zirh-$formid");
$bileklik = gvn::post("bileklik-$formid");
$ayakkabi = gvn::post("ayakkabi-$formid");
$kolye    = gvn::post("kolye-$formid");
$kask     = gvn::post("kask-$formid");
$kalkan   = gvn::post("kalkan-$formid");
$kupe     = gvn::post("kupe-$formid");
$kontrol  = $odb->prepare( "SELECT apply FROM player.item_attr_rare WHERE apply = ?" );
$kontrol->execute( array(
     $apply 
) );
if ( $kontrol->rowCount() ) {
    $update   = $odb->prepare( "UPDATE player.item_attr_rare SET prob = ?, lv1 = ?, lv2 = ?, lv3 = ?, lv4 = ?, lv5 = ?, weapon = ?, body = ?, wrist = ?, foots = ?, neck = ?, head = ?, shield = ?, ear = ? WHERE apply = ?" );
    $guncelle = $update->execute( array(
         $gelme,
        $lv1,
        $lv2,
        $lv3,
        $lv4,
        $lv5,
        $silah,
        $zirh,
        $bileklik,
        $ayakkabi,
        $kolye,
        $kask,
        $kalkan,
        $kupe,
        $apply 
    ) );
    if ( $guncelle ) {
        $WMadmin->log_gonder( $apply . " Adlı 2.efsun düzenlendi" );
        $WMform->basari( "Efsun başarıyla güncellendi" );
    } else {
        $WMform->hata();
    }
} else {
    $WMform->hata( "Düzenleme çalıştığınız efsun artık yok ! " );
}
?>