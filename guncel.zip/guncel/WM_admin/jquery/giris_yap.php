<?php
class login
{
    public function __construct( $username, $password )
    {
        global $db;
        $query = $db->prepare( "SELECT username,password,server,id FROM users WHERE username = ? && password = ?" );
        $query->execute( array(
             $username,
             $password
        ) );
        if ( $query->rowCount() ) {
            $fetch = $query->fetch( PDO::FETCH_ASSOC );
            $this->session_olustur( $fetch[ "id" ], $username, $fetch[ "server" ] );
            echo 1;
        } else {
            echo 2;
        }
    }
    public function session_olustur( $userid, $username, $serverid )
    {
        global $db;
        session_start();
        $_SESSION[ "adminid" ]   = intval($userid);
        $_SESSION[ "adminisim" ] = $username;
        $_SESSION[ "giris" ]     = "true";
        $_SESSION[ "server" ]    = $serverid;
        $log_gonder              = $db->prepare( "INSERT INTO log (sid, tur, yapan, log, tarih) values (?, ?, ?, ?, ?)" );
        $log_gonder->execute( array(
             $serverid,
            4,
            $username,
            $_SERVER[ 'REMOTE_ADDR' ],
            date( "Y-m-d H:i:s" ) 
        ) );
    }
}
$login = new login( gvn::post('username'), md5( gvn::post('password') ) );
?>
