<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('formid');
if ( $fid == 1 ) {
	
	if(isset($_SESSION['veri_silme'])){
	
    $vnum = gvn::post('vnum');
    $sil  = $odb->prepare( "DELETE FROM player.item WHERE vnum = ?" );
    $sil->execute( array(
         $vnum 
    ) );
    if ( $sil ) {
        $WMform->basari( $vnum . " vnumlu itemler başarıyla silindi" );
        $WMadmin->log_gonder( $vnum . " vnumlu itemler silindi" );
    } else {
        $WMform->hata();
    }
	
	}
	else{
		$WMform->hata("Veri silme şifrenizi girmediniz. Yönlendiriliyorsunuz");
		printf('<meta http-equiv="refresh" content="2;URL=index.php?sayfa=veri_silme_sifresi">');
	}
	
} else if ( $fid == 2 ) {
    $sil = $odb->prepare( "DELETE FROM player.item" );
    $sil->execute();
    if ( $sil ) {
        $WMform->basari( "Oyundaki tüm itemler silindi" );
        $WMadmin->log_gonder( "Oyundaki tüm itemler silindi" );
    } else {
        $WMform->hata();
    }
}
?>