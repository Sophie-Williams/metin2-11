<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}

session_start();

$pass = gvn::post('pass');
$pass_retry = gvn::post('pass_retry');

if($pass != $pass_retry){
	$WMform->hata("Şifreler eşleşmedi");
}
else{
	if($pass != veriSilmeSifresi){
		$WMform->hata("Veri silme şifrenizi yanlış girdiniz");
	}
	else{
		$WMform->basari("Veri silme şifrenizi doğru girdiniz artık veri silmeye başlayabilirsiniz");
		$_SESSION['veri_silme'] = true;
	}
}

?>