<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}

session_start();

$apikey   = gvn::post('apikey');
$hashcode    = gvn::post('hashcode');

$array = array('apikey'=> $apikey, 'hashcode'=>$hashcode);

$guncelle = $db->prepare("UPDATE server SET sanalpay = ? WHERE id = ?");
$guncelle->execute(array(json_encode($array), $_SESSION['server']));

if($guncelle->errorInfo()[2] == false){
	$WMform->basari("Mağaza ayarlarınız başarıyla güncellendi");
}
else{
	$WMform->hata();
}

?>