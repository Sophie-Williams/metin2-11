<?php
if ( !defined( "WM_IZIN_KONTROL" ) ) {
    die( "Buraya giriş izniniz yoktur." );
    exit;
}
session_start();
$fid = gvn::get('formid');
if ( $fid == 1 ) {
    $exp      = gvn::post('exp');
    $yang     = gvn::post('yang');
    $dusme    = gvn::post('dusme');
    $drop     = $exp . ',' . $yang . ',' . $dusme;
    $update   = $db->prepare( "UPDATE `server` SET `drop` = ? WHERE `server`.`id` = ?" );
    $guncelle = $update->execute( array(
         $drop,
        $_SESSION[ "server" ] 
    ) );
    if ( $guncelle ) {
        $WMadmin->log_gonder( $WMadmin->serverbilgi( "isim" ) . " Adlı serverın files ayarları değiştirildi" );
        $WMform->basari( "Files ayarları başarıyla güncellendi" );
    } else {
        $WMform->hata();
    }
} else if ( $fid == 2 ) {
    $envanter = gvn::post('envanter');
    $efsun    = gvn::post('efsun');
    $tas    = gvn::post('tas');
    if ( $efsun < 0 || $efsun > 7 ) {
        $WMform->hata( "Efsun en fazla 7 en az 0 olabilir" );
    } else if ( $envanter < 2 || $envanter > 5 ) {
        $WMform->hata( "Envanter en fazla 5 en az 2 olabilir" );
    } else {
        $update   = $db->prepare( "UPDATE `server` SET `envanter` = ?, `market_efsun` = ?, `tas` = ? WHERE `server`.`id` = ?" );
        $guncelle = $update->execute( array(
             $envanter,
            $efsun,
			$tas,
            $_SESSION[ "server" ] 
        ) );
        if ( $guncelle ) {
            $WMadmin->log_gonder( $WMadmin->serverbilgi( "isim" ) . " Adlı serverın files ayarları değiştirildi" );
            $WMform->basari( "Files ayarları başarıyla güncellendi" );
        } else {
            $WMform->hata();
        }
    }
}
?>