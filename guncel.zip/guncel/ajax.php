<?php

$konum = ".";

require_once "WM_settings/WMayar.php";

define('server', $_SESSION[ "server_vt" ]);

$ayar = new WMayar( ".", server );

$p = gvn::get('p');

if(empty($p)){
	
}
else{
	
	if(file_exists(dirname(__FILE__) . '/ajax/'.$p.'.php')){
		
		$vt   = new WM_vt_settings( $_SESSION[ "server_vt" ] );
		
		require_once(dirname(__FILE__) . '/ajax/'.$p.'.php');
		
		$ln = gvn::get('ln');
		
		if($ln != ''){
			$get = json_decode($ln, true);
		}
		
		$class = 'Post_'.$p;
		
		$class::post();
		
	}
	else{
		form::hata('Sistem hatası meydana geldi');
	}
	
	
}


?>