<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div style="margin-bottom:10px;"></div>

<hr>

<center><a href="kullanici/ep-satin-al#sanalpayModal"><img src="http://sanalpay.com.tr/modal/satinal.jpg"></a></center>


<div style="margin-bottom:20px;"></div>


<link rel="stylesheet" href="https://www.sanalpay.com.tr/modal/modal.css">  
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="https://www.sanalpay.com.tr/modal/modal.js"></script>
	

<div class="remodal" data-remodal-id="sanalpayModal"> 
	<div class="login-body">
						

		<?php 
		if(isset($_SESSION[$vt->a("isim")."username"])){
			
			
		$sanalpay = json_decode($vt->a("sanalpay"), true);
		
		function GetIP(){
			if(getenv("HTTP_CLIENT_IP")) {
				$ip = getenv("HTTP_CLIENT_IP");
			} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
				$ip = getenv("HTTP_X_FORWARDED_FOR");
				if (strstr($ip, ',')) {
					$tmp = explode (',', $ip);
					$ip = trim($tmp[0]);
				}
			} else {
			$ip = getenv("REMOTE_ADDR");
			}
			return $ip;
		}

		$jSon_html = 'https://magaza.sanalpay.com.tr/api/json_api.php';		

		$aPiKey = $sanalpay['apikey'];		

		$hashKey = $sanalpay['hashcode'];				

		define('HASH_KEYWORDS', $hashKey);				

		function encrypt($hash) {		
		$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);		
		$passcrypt = trim(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, HASH_KEYWORDS, trim($hash), MCRYPT_MODE_ECB, $iv));		
		$encode = base64_encode($passcrypt);		
		return $encode;		
		}		

		$userId = $vt->uye("id");		

		$userName = $_SESSION[$vt->a("isim")."username"];		

		$userMail = $vt->uye("email");		
										
		$userAdSoyad = $vt->uye("real_name");								        


		$ch = curl_init();         
		curl_setopt($ch, CURLOPT_URL, $jSon_html);         
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);           
		curl_setopt($ch, CURLOPT_VERBOSE, 1);		  
		 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);		   
		 curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);		   
		 $srv_param = array(			   
		 'Api-Key' => $aPiKey,			   
		 'userId' => $userId,			   
		 'hashKey' => $hashKey,		   
		 'userName' => $userName,			   
		 'userMail' => $userMail,			   
		 'adSoyad' => $userAdSoyad,
		 'ipAdress' => GetIP(), 
		 'randomSession' => md5(encrypt("$userId|$userName|$userMail|$aPiKey"))	   );		   
		 curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($srv_param));          
		 $result = curl_exec($ch);		   
		 $error = curl_error($ch);							   
		 if($error){					   
		 print('Curl Error : ' . $error );			   
		 }		
		 else{				  
		 $jsondecode = json_decode($result);		   
		 if($jsondecode->Return == 'Success'){	   ?>	   
		 <iframe seamless="seamless" style="display:block; margin:0; padding:0; width:1000px; height:80vh; background:#fff;" id="ex3" frameborder="0" scrolling='yes' src="<?=$jsondecode->Result;?>">
		 </iframe>				   
		 <?php			   
		 }		  
		 else if($jsondecode->Return == 'Error'){
			 print('Error : '. $jsondecode->Result);						   
			 }		   
			 else{				   
			 print($result);		   
			 }				   
			 }		   
			 }
			else	
			{
				echo 'Üye girişi yapmadan bu sayfayı göremezsiniz..';
			}
		?>		
			

			

			</div>				</div>

			
<table class="indirtbl">
  <tr>
	  <th width="45%" align="center">Ep Miktarı</th>
	  <th width="40%" align="center">Fiyat</th>
	  <th width="30%" align="center">İşlemler</th>
  </tr>
  <?php 
  foreach($epfiyatlari as $epfiyat){
  ?>
  <form action="javascript:;" id="epsatinal" variable="<?=$epfiyat['id'];?>"  method="post">
  <tr>
      <td><?=$epfiyat["ep"];?> EP</td>
      <td><?=$epfiyat["fiyat"];?> TL</td>
      <td>
	   <input name="satinal" type="submit" value="Satın Al" />
	  </td>
  </tr>
  </form>
  <?php } ?>
</table>

