<?php
class kullanici_bugdan_kurtar {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_bugdan_kurtar/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_bugdan_kurtar/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return 'Bugdan Kurtar';
    }
    public function orta( ) {
        global $ayar, $WMkontrol, $vt, $db, $odb, $tema;
        if ( $vt->a( "breadcumb" ) == 1 ) {
            if ( file_exists( WM_tema . 'sayfalar/kullanici_bugdan_kurtar/breadcumb.php' ) ) {
                require_once WM_tema . 'sayfalar/kullanici_bugdan_kurtar/breadcumb.php';
            } else {
                require_once Sayfa_html . 'breadcumb.php';
            }
        }
        if ( file_exists( WM_tema . 'sayfalar/kullanici_bugdan_kurtar/bugdan_kurtar.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_bugdan_kurtar/bugdan_kurtar.php';
        } else {
            require_once Sayfa_html . 'bugdan_kurtar.php';
        }
    }
}
?>