<?php
class giris_yap {
   public function head( ) {
      global $vt;
      if ( file_exists( WM_tema . 'sayfalar/giris_yap/header.php' ) ) {
         require_once WM_tema . 'sayfalar/giris_yap/header.php';
      } else {
         require_once Sayfa_html . 'header.php';
      }
   }
   public function ust( ) {
      global $vt;
      return $vt->a( "isim" ) . ' - Giriş Yap';
   }
   public function orta( ) {
      global $odb, $vt, $ayar, $tema;
      if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
         @$onay_gonder = gvn::get('onay_gonder');
         if ( $onay_gonder == 1 && isset( $_SESSION[ "hesap_onay" ] ) ) {
            $token       = $ayar->token_rastgele;
            $vt->token_ekle( 1, $_SESSION[ "hesap_onay" ], $token );
			$mail_icerik = array('kayit_onay', $_SESSION[ "hesap_onay" ], 
			$vt->a( "link" ) . 'kayit_onay?token=' . $token . '&user=' . $_SESSION[ "hesap_onay" ]
			);
            $gonder = $vt->mail_gonder( $_SESSION[ "hesap_onay_mail" ], "Hesabınızı Onaylayın", $mail_icerik );
            if ( $gonder ) {
               $tema->basari( "Hesap onaylama maili tekrar gönderildi" );
            } else {
               $tema->hata( "Mail gönderilemedi" );
            }
            unset( $_SESSION[ "hesap_onay" ] );
            unset( $_SESSION[ "hesap_onay_mail" ] );
         }
         if ( file_exists( WM_tema . 'sayfalar/giris_yap/giris_yap.php' ) ) {
            require_once WM_tema . 'sayfalar/giris_yap/giris_yap.php';
         } else {
            require_once Sayfa_html . 'giris_yap.php';
         }
      } else {
         if ( file_exists( WM_tema . 'sayfalar/giris_yap/hata.php' ) ) {
            require_once WM_tema . 'sayfalar/giris_yap/hata.php';
         } else {
            require_once Sayfa_html . 'hata.php';
         }
      }
   }
}
?>