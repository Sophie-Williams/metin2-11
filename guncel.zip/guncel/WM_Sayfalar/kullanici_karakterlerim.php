<?php

class kullanici_karakterlerim {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_karakterlerim/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return $vt->a( "isim" ) . ' - Karakterlerim';
    }
    public function orta( ) {
        global $ayar, $WMkontrol, $vt, $db, $tema, $odb, $WMinf;
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            $vt->yonlendir( $vt->url( 4 ) );
        } else {
            @$karakter_duzenle = gvn::get('karakter_duzenle');
            @$karakter = gvn::get('karakter');
            @$guild_id = gvn::get('guild_id');
            @$sosyal_kontrol = $odb->prepare( "SELECT imza, sosyal FROM player.player LIMIT 1" );
            @$sosyal_kontrol->execute( );
            if ( ( !$karakter_duzenle || $karakter_duzenle == "" ) && ( !$guild_id || !$karakter ) ) {
                $karakterler = $odb->prepare( "SELECT id,name,job,level,alignment,exp FROM player.player WHERE account_id = ? ORDER BY level DESC" );
                $karakterler->execute( array(
                     $_SESSION[ $vt->a( "isim" ) . "userid" ] 
                ) );
                if ( $vt->a( "breadcumb" ) == 1 ) {
                    if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb.php' ) ) {
                        require_once WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb.php';
                    } else {
                        require_once Sayfa_html . 'breadcumb.php';
                    }
                }
                if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/karakterleri.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_karakterlerim/karakterleri.php';
                } else {
                    require_once Sayfa_html . 'karakterleri.php';
                }
            } else if ( $guild_id != '' && $karakter != '' ) {
                $lonca_sosyal = $odb->prepare( "SELECT sosyal FROM player.guild LIMIT 1" );
                $lonca_sosyal->execute( );
                if ( $lonca_sosyal->errorInfo()[2] == false ) {
                    $karakter_kontrol = $odb->prepare( "SELECT id,name,job FROM player.player WHERE account_id = ? && id = ?" );
                    $karakter_kontrol->execute( array(
                         $_SESSION[ $vt->a( "isim" ) . "userid" ],
						 gvn::get('karakter')
                    ) );
                    if ( $karakter_kontrol->rowCount() ) {
                        $lonca_kontrol = $odb->prepare( "SELECT * FROM player.guild WHERE master = ?" );
                        $lonca_kontrol->execute( array(
                             $karakter 
                        ) );
                        if ( $lonca_kontrol->rowCount() ) {
                            $karakter_fetch = $karakter_kontrol->fetch( PDO::FETCH_ASSOC );
                            $lonca_fetch    = $lonca_kontrol->fetch( PDO::FETCH_ASSOC );
                            if ( $vt->a( "breadcumb" ) == 1 ) {
                                if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb_2.php' ) ) {
                                    require_once WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb_2.php';
                                } else {
                                    require_once Sayfa_html . 'breadcumb_2.php';
                                }
                            }
                            $sosyal_lonca = json_decode( $lonca_fetch[ "sosyal" ] );
                            if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/karakter_bilgi.php' ) ) {
                                require_once WM_tema . 'sayfalar/kullanici_karakterlerim/karakter_bilgi.php';
                            } else {
                                require_once Sayfa_html . 'karakter_bilgi.php';
                            }
                        } else {
                            $vt->yonlendir( "kullanici/karakterlerim" );
                        }
                    } else {
                        $vt->yonlendir( "kullanici/karakterlerim" );
                    }
                } else {
                    $vt->yonlendir( "kullanici/karakterlerim" );
                }
            } else {
                if ( $sosyal_kontrol->errorInfo()[2] == false ) {
                    $kontrol = $odb->prepare( "SELECT id,imza,sosyal,name,job FROM player.player WHERE id = ? && account_id = ?" );
                    $kontrol->execute( array(
                         $karakter_duzenle,
                        $_SESSION[ $vt->a( "isim" ) . "userid" ] 
                    ) );
                    if ( $kontrol->rowCount() ) {
                        $fetch = $kontrol->fetch( PDO::FETCH_ASSOC );
                        if ( $vt->a( "breadcumb" ) == 1 ) {
                            if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb_3.php' ) ) {
                                require_once WM_tema . 'sayfalar/kullanici_karakterlerim/breadcumb_3.php';
                            } else {
                                require_once Sayfa_html . 'breadcumb_3.php';
                            }
                        }
                        $sosyal       = json_decode( $fetch[ "sosyal" ] );
                        $lonca_baskan = $odb->prepare( "SELECT name,id FROM player.guild WHERE master = ?" );
                        $lonca_baskan->execute( array(
                             $fetch[ "id" ] 
                        ) );
                        if ( file_exists( WM_tema . 'sayfalar/kullanici_karakterlerim/karakter_sosyal.php' ) ) {
                            require_once WM_tema . 'sayfalar/kullanici_karakterlerim/karakter_sosyal.php';
                        } else {
                            require_once Sayfa_html . 'karakter_sosyal.php';
                        }
                    } else {
                        $vt->yonlendir( "kullanici/karakterlerim" );
                    }
                }
            }
        }
    }
}
?>