<?php
class kullanici_adi_unuttum {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_adi_unuttum/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_adi_unuttum/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return $vt->a( "isim" ) . ' - Kullanıcı Adımı Unuttum';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema;
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            if ( $vt->a( "kullanici_unuttum" ) == 1 ) {
                if ( file_exists( WM_tema . 'sayfalar/kullanici_adi_unuttum/kullanici_adi_unuttum.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_adi_unuttum/kullanici_adi_unuttum.php';
                } else {
                    require_once Sayfa_html . 'kullanici_adi_unuttum.php';
                }
            } else {
                $vt->yonlendir( $vt->url( 0 ) );
            }
        } else {
            $vt->yonlendir( $vt->url( 5 ) );
        }
    }
}
?>