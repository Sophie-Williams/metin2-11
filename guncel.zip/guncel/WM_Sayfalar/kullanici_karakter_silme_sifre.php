<?php
class kullanici_karakter_silme_sifre {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return ' Karakter Silme Şifresi Değiştir';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema;
        if ( isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            if ( $vt->a( "breadcumb" ) == 1 ) {
                if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/breadcumb.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/breadcumb.php';
                } else {
                    require_once Sayfa_html . 'breadcumb.php';
                }
            }
            if ( $vt->a( "karakter_silme_sifre" ) == 1 || $vt->a( "karakter_silme_sifre" ) == 2 ) {
                if ( $vt->a( "karakter_silme_sifre" ) == 1 ) {
                        $karakter_token = gvn::get('karakter_token');
                        if ( !$karakter_token ) {
                            if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_gonder.php' ) ) {
                                require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_gonder.php';
                            } else {
                                require_once Sayfa_html . 'sifre_gonder.php';
                            }
                        } else {
                            $degistir_kontrol = $db->prepare( "SELECT token FROM token WHERE sid = ? && tur = ? && login = ? && token = ?" );
                            $degistir_kontrol->execute( array(
                                 server,
                                6,
                                $_SESSION[ $vt->a( "isim" ) . "username" ],
                                $karakter_token 
                            ) );
                            if ( $degistir_kontrol->rowCount() ) {
                                if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_degis_mail.php' ) ) {
                                    require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_degis_mail.php';
                                } else {
                                    require_once Sayfa_html . 'sifre_degis_mail.php';
                                }
                            } else {
                                $tema->hata( "Karakter Silme Şifrenizi bu tokenle değiştiremezsiniz .. ! Tokeninizi bilmiyorsanız veya mailinize gelmediyse lütfen tekrar göndermeyi deneyin." );
                                printf( '<meta http-equiv="refresh" content="4;URL=' . $vt->url( 5 ) . '">' );
                            }
                        }
                } else if ( $vt->a( "karakter_silme_sifre" ) == 2 ) {
                    
                        if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sistem_degisecek.php' ) ) {
                            require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sistem_degisecek.php';
                        } else {
                            require_once Sayfa_html . 'sistem_degisecek.php';
                        }
                }
            } else if ( $vt->a( "karakter_silme_sifre" ) == 3 ) {
                if ( file_exists( WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_degis.php' ) ) {
                    require_once WM_tema . 'sayfalar/kullanici_karakter_silme_sifre/sifre_degis.php';
                } else {
                    require_once Sayfa_html . 'sifre_degis.php';
                }
            }
        } else {
            $vt->yonlendir( $vt->url( 4 ) );
        }
    }
}
?>