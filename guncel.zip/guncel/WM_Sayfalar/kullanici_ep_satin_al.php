<?php
class kullanici_ep_satin_al {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_satin_al/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kullanici_ep_satin_al/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return $vt->a( "title" ) . ' - EP Satın Al';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema;
        $epfiyatlari = $db->prepare( "SELECT * FROM epfiyatlari WHERE sid = ? ORDER BY sira" );
        $epfiyatlari->execute( array(
             server 
        ) );
        if ( $vt->a( "breadcumb" ) == 1 ) {
            if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_satin_al/breadcumb.php' ) ) {
                require_once WM_tema . 'sayfalar/kullanici_ep_satin_al/breadcumb.php';
            } else {
                require_once Sayfa_html . 'breadcumb.php';
            }
        }
        @$kontrol2 = $odb->prepare( "SELECT bakiye FROM account LIMIT 1" );
        @$kontrol2->execute( );
        echo html_entity_decode( $vt->a( "odeme" ) );
        if ( $kontrol2->errorInfo()[2] == false ) {
            if ( file_exists( WM_tema . 'sayfalar/kullanici_ep_satin_al/ep_satin_al.php' ) ) {
                require_once WM_tema . 'sayfalar/kullanici_ep_satin_al/ep_satin_al.php';
            } else {
                require_once Sayfa_html . 'ep_satin_al.php';
            }
        }
    }
}
?>