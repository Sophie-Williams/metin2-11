<?php
class kaydol {
    public function head( ) {
        global $vt;
        if ( file_exists( WM_tema . 'sayfalar/kaydol/header.php' ) ) {
            require_once WM_tema . 'sayfalar/kaydol/header.php';
        } else {
            require_once Sayfa_html . 'header.php';
        }
    }
    public function ust( ) {
        global $vt;
        return $vt->a( "isim" ) . ' - Kayıt Ol';
    }
    public function orta( ) {
        global $ayar, $odb, $WMkontrol, $vt, $db, $tema, $WMclass, $davete_yes;
        if ( !isset( $_SESSION[ $vt->a( "isim" ) . "token" ] ) ) {
            if ( $vt->a( "kayit" ) == 2 ) {
                $tema->uyari( "Oyunumuz yapım aşamasında olduğu için kayıtları alamıyoruz." );
            } else {
                @$eptransfer_sistem = $db->prepare( "SELECT eptransfer FROM server LIMIT 1" );
                @$eptransfer_sistem->execute();
                if ( $eptransfer_sistem->errorInfo()[2] == false ) {
                    @$eptransfer = explode( ',', $vt->a( "eptransfer" ) );
                    if ( $eptransfer[ 0 ] == 1 ) {
                        $sistem_true = true;
                    }
                }
                if ( @$vt->a( "davet_durum" ) == 1 ) {
                    @$davet_token = gvn::get('davet');
                    if ( $davet_token != "" ) {
                        $kontrol = $odb->prepare( "SELECT * FROM account WHERE davet = ?" );
                        $kontrol->execute( array(
                             $davet_token 
                        ) );
                        if ( $kontrol->rowCount() ) {
                            $davete_yes = $davet_token;
                        } else {
                            $davete_yes = "";
                            $tema->hata( "Bu tokene ait bir davetçi bulunamadı. ! Kayıt olur iseniz davet edilmemiş olarak sisteme geçiceksiniz." );
                        }
                    }
                } else {
                    $davete_yes = "";
                }
                if ( file_exists( WM_tema . 'sayfalar/kaydol/kayit_form.php' ) ) {
                    require_once WM_tema . 'sayfalar/kaydol/kayit_form.php';
                } else {
                    require_once Sayfa_html . 'kayit_form.php';
                }
            }
        } else {
            $tema->hata( "Giriş Yapıldıktan sonra bu sayfayı göremezsiniz.." );
        }
    }
}
?>