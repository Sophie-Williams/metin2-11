<?php

require_once('WM_class/get.php');

?>